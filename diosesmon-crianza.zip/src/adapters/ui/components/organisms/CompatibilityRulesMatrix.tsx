import React, { useState } from 'react';
import { Flame, Coins, Check, X, BookOpen } from 'lucide-react';
import { EggGroup } from '../../../../domain/types/eggGroup';
import { EGG_GROUP_NAMES_ES } from '../../../../domain/data/speciesData';
import { DIOSESMON_ITEM_COSTS, ITEM_NAMES_ES, ITEM_DESCRIPTIONS_ES, ItemType } from '../../../../domain/types/items';

export const CompatibilityRulesMatrix: React.FC = () => {
  const [selectedGroupA, setSelectedGroupA] = useState<EggGroup>(EggGroup.Monster);
  const [selectedGroupB, setSelectedGroupB] = useState<EggGroup>(EggGroup.Dragon);

  // Group list for matrix
  const groups = [
    EggGroup.Monster,
    EggGroup.Water1,
    EggGroup.Bug,
    EggGroup.Flying,
    EggGroup.Field,
    EggGroup.Fairy,
    EggGroup.Grass,
    EggGroup.HumanLike,
    EggGroup.Water3,
    EggGroup.Mineral,
    EggGroup.Amorphous,
    EggGroup.Water2,
    EggGroup.Ditto,
    EggGroup.Dragon,
    EggGroup.Undiscovered,
  ];

  const areCompatible = (g1: EggGroup, g2: EggGroup) => {
    if (g1 === EggGroup.Undiscovered || g2 === EggGroup.Undiscovered) return false;
    if (g1 === EggGroup.Ditto || g2 === EggGroup.Ditto) return true;
    return g1 === g2;
  };

  const isCompatibleSelection = areCompatible(selectedGroupA, selectedGroupB);

  return (
    <div className="w-full flex flex-col gap-5 p-5 rounded-2xl bg-[#0b0f19] border border-purple-500/25 shadow-xl">
      {/* Header */}
      <div className="border-b border-slate-800 pb-3">
        <h3 className="text-lg font-bold font-['Sora'] text-white flex items-center gap-2">
          <BookOpen className="w-4 h-4 text-purple-400" />
          Matriz de Compatibilidad & Catálogo Oficial Diosesmon
        </h3>
        <p className="text-xs text-slate-400 mt-1">
          Auditoría de Grupos Huevo, compatibilidad con Ditto y lista de precios oficial del NPC
        </p>
      </div>

      {/* Interactive Compatibility Checker */}
      <div className="p-4 rounded-xl bg-[#0f131c] border border-slate-800 flex flex-col gap-3">
        <span className="text-xs font-semibold text-white uppercase tracking-wider font-mono">
          Verificador Rápido de Compatibilidad
        </span>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3 items-center">
          <div>
            <label className="text-[11px] text-slate-400 block mb-1">Grupo Huevo Padre ♂</label>
            <select
              value={selectedGroupA}
              onChange={(e) => setSelectedGroupA(e.target.value as EggGroup)}
              className="w-full text-xs px-3 py-2 rounded bg-[#0a0e17] border border-slate-700 text-white"
            >
              {groups.map((g) => (
                <option key={g} value={g}>
                  {EGG_GROUP_NAMES_ES[g] || g}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="text-[11px] text-slate-400 block mb-1">Grupo Huevo Madre ♀</label>
            <select
              value={selectedGroupB}
              onChange={(e) => setSelectedGroupB(e.target.value as EggGroup)}
              className="w-full text-xs px-3 py-2 rounded bg-[#0a0e17] border border-slate-700 text-white"
            >
              {groups.map((g) => (
                <option key={g} value={g}>
                  {EGG_GROUP_NAMES_ES[g] || g}
                </option>
              ))}
            </select>
          </div>

          <div className="flex flex-col items-center justify-center p-2.5 rounded-lg bg-slate-900 border border-slate-800">
            <span className="text-[10px] text-slate-500 uppercase font-mono">Compatibilidad</span>
            <div className="flex items-center gap-1.5 mt-0.5">
              {isCompatibleSelection ? (
                <>
                  <Check className="w-4 h-4 text-emerald-400" />
                  <span className="text-xs font-bold text-emerald-400">100% Compatibles</span>
                </>
              ) : (
                <>
                  <X className="w-4 h-4 text-rose-400" />
                  <span className="text-xs font-bold text-rose-400">Incompatibles</span>
                </>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Official NPC Catalog */}
      <div className="p-4 rounded-xl bg-[#0f131c] border border-slate-800 flex flex-col gap-3">
        <div className="flex items-center justify-between">
          <span className="text-xs font-semibold text-white uppercase tracking-wider font-mono flex items-center gap-1.5">
            <Coins className="w-3.5 h-3.5 text-amber-400" />
            Catálogo Oficial de Precios NPC (Servidor Diosesmon)
          </span>
          <span className="text-[11px] text-rose-400 font-mono">
            ★ Todos son 1x Burn (Consumibles por cruza)
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-2.5">
          {Object.entries(DIOSESMON_ITEM_COSTS).map(([itemKey, price]) => {
            const itemType = itemKey as ItemType;
            const name = ITEM_NAMES_ES[itemType] || itemKey;
            const desc = ITEM_DESCRIPTIONS_ES[itemType] || '';
            const isEverstone = itemType === ItemType.Everstone;

            return (
              <div
                key={itemKey}
                className="p-3 rounded-lg bg-[#0a0e17] border border-slate-800/80 flex flex-col justify-between gap-1.5"
              >
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-white flex items-center gap-1.5">
                    <Flame className={`w-3.5 h-3.5 ${isEverstone ? 'text-purple-400' : 'text-rose-400'}`} />
                    {name}
                  </span>
                  <span className="text-xs font-mono font-bold text-amber-300">
                    {price.toLocaleString()} Pk$
                  </span>
                </div>
                <p className="text-[11px] text-slate-400 leading-snug">{desc}</p>
                <div className="flex items-center justify-between text-[10px] text-slate-500 font-mono pt-1 border-t border-slate-800/60">
                  <span>1x Burn</span>
                  <span>NPC Oficial Diosesmon</span>
                </div>
              </div>
            );
          })}

          {/* Daycare service entry */}
          <div className="p-3 rounded-lg bg-[#0a0e17] border border-amber-500/30 flex flex-col justify-between gap-1.5">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-white flex items-center gap-1.5">
                <Coins className="w-3.5 h-3.5 text-amber-400" />
                Tarifa de Guardería
              </span>
              <span className="text-xs font-mono font-bold text-amber-300">
                20,000 Pk$
              </span>
            </div>
            <p className="text-[11px] text-slate-400 leading-snug">
              Cuota de servicio cobrada por el NPC por cada ciclo de incubación y entrega de huevo.
            </p>
            <div className="flex items-center justify-between text-[10px] text-amber-400/80 font-mono pt-1 border-t border-slate-800/60">
              <span>Por cada cruza</span>
              <span>Guardería Diosesmon</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CompatibilityRulesMatrix;
