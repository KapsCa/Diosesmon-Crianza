import React, { useState } from 'react';
import type { TreeNode, BreedingTree as BreedingTreeType } from '../../../../domain/types/route';
import { BreedingTreePro } from './BreedingTreePro';

interface BreedingTreeProps {
  /** Datos del árbol de breeding */
  treeData: BreedingTreeType;
  /** Si true, muestra modo simple (resumido); false = modo avanzado */
  simpleMode?: boolean;
  /** Callback opcional cuando un nodo es expandido/collapse o cambia de modo */
  onNodeToggle?: (nodeId: string) => void;
  /** Nombre opcional de la especie objetivo */
  targetSpeciesName?: string;
}

/**
 * Obtiene el ícono o indicador del estado del nodo
 */
function getNodeStatusIcon(node: TreeNode): string {
  if (!node.step) {
    return '🌱'; // Nodo base (semilla)
  }
  if (node.children.length === 0) {
    return '💧'; // Nodo hoja (no hay más crías)
  }
  return '🌳'; // Nodo interno
}

/**
 * Renderiza un nodo individual del árbol
 */
function renderNode(
  node: TreeNode,
  simpleMode: boolean,
  depth: number = 0,
  index: number = 0,
  prefix: string = 'root'
): React.ReactElement {
  const icon = getNodeStatusIcon(node);
  const pokemon = node.pokemon;

  // Información básica que siempre se muestra
  const basicInfo = (
    <span className="node-pokemon text-sm font-semibold text-white">
      {pokemon.species.name}
      {simpleMode ? '' : ` (Lvl ${node.progressLevel})`}
    </span>
  );

  // Información adicional en modo avanzado
  const advancedInfo = simpleMode ? null : (
    <div className="node-advanced text-xs text-slate-400 mt-1 flex flex-wrap gap-2">
      <span className="node-ivs text-emerald-400 font-mono">
        IVs: {Object.entries(pokemon.ivs)
          .filter(([, val]) => val === 31)
          .map(([key]) => key)
          .join(', ') || 'ninguno'}
      </span>
      <span className="node-gender text-sky-400 font-medium">Género: {pokemon.gender}</span>
      {node.step?.fatherItem || node.step?.motherItem ? (
        <span className="node-items text-purple-400 font-mono">
          {node.step.fatherItem ? 'Power Item ' + node.step.fatherItem.type : ''}
          {node.step.motherItem ? ', Power Item ' + node.step.motherItem.type : ''}
        </span>
      ) : ''}
    </div>
  );

  // Generar una key única para el nodo combinando prefijo, paso, especie, nivel y profundidad
  const nodeKey = `${prefix}-${node.step?.id || 'base'}-${pokemon.species.id}-${node.progressLevel}-${depth}-${index}`;

  return (
    <div
      key={nodeKey}
      className="breeding-node p-3 rounded-lg bg-slate-900/60 border border-slate-800 hover:border-purple-500/40 transition-all mb-2"
      style={{ marginLeft: `${16 * depth}px` }}
      role="button"
      aria-pressed={node.children.length > 0}
      aria-label={
        simpleMode
          ? `Nodo ${nodeKey}: ${pokemon.species.name}, progreso ${node.progressLevel}`
          : `Nodo ${nodeKey}: ${pokemon.species.name}, ${Object.keys(pokemon.ivs).length} stats, ${node.progressLevel} nivel(es), ${node.step ? 'paso de cría' : 'nodo base'}, ${node.children.length} hijo(s)`
      }
    >
      <div className="node-header flex items-center gap-2">
        <span className="node-icon">{icon}</span>
        <span className="node-name font-bold text-white text-sm">{pokemon.species.name}</span>
        <span className="node-progress text-xs px-2 py-0.5 rounded bg-purple-500/20 text-purple-300 font-mono">
          Progreso: {node.progressLevel}x31
        </span>
      </div>

      <div className="node-content mt-1.5">{basicInfo}{advancedInfo}</div>

      {node.children.length > 0 && (
        <div className="node-children mt-2 border-l border-purple-500/30 pl-3">
          {node.children.map((child, childIdx) =>
            renderNode(child, simpleMode, depth + 1, childIdx, `${nodeKey}-child`)
          )}
        </div>
      )}
    </div>
  );
}

export const BreedingTree: React.FC<BreedingTreeProps> = ({
  treeData,
  simpleMode = false,
  onNodeToggle,
  targetSpeciesName,
}) => {
  const [internalSimpleMode, setInternalSimpleMode] = useState(simpleMode);
  const effectiveSimpleMode = onNodeToggle ? simpleMode : internalSimpleMode;

  const handleToggle = (mode: 'simple' | 'advanced') => {
    setInternalSimpleMode(mode === 'simple');
    onNodeToggle?.(mode);
  };

  return (
    <div className="breeding-tree-container flex flex-col gap-5 w-full">
      {/* Visual Pro Tree with Zoom, Generations, and 1x Burn Financial Audit */}
      <BreedingTreePro
        treeData={treeData}
        targetSpeciesName={targetSpeciesName || treeData.root?.pokemon?.species?.name}
        simpleMode={effectiveSimpleMode}
        onModeToggle={handleToggle}
      />

      {/* Structured Nodes List */}
      <div className="p-4 rounded-xl bg-[#0f131c] border border-slate-800 flex flex-col gap-3">
        <header className="breeding-tree-header flex items-center justify-between border-b border-slate-800 pb-2">
          <h3 className="tree-title text-sm font-semibold text-white flex items-center gap-2">
            <span>Jerarquía Estructurada de Nodos</span>
            <span className="text-xs text-slate-500 font-normal font-mono">
              ({treeData.allNodes.length} nodos)
            </span>
          </h3>
          <div className="mode-toggle flex items-center gap-3 text-xs text-slate-300">
            <label className="flex items-center gap-1.5 cursor-pointer">
              <input
                type="radio"
                name="tree-mode"
                value="simple"
                checked={effectiveSimpleMode}
                onChange={() => handleToggle('simple')}
              />
              Simple
            </label>
            <label className="flex items-center gap-1.5 cursor-pointer">
              <input
                type="radio"
                name="tree-mode"
                value="advanced"
                checked={!effectiveSimpleMode}
                onChange={() => handleToggle('advanced')}
              />
              Avanzado
            </label>
          </div>
        </header>

        <section className="tree-nodes flex flex-col gap-1 max-h-96 overflow-y-auto pr-1">
          {treeData.allNodes.map((node, nodeIdx) =>
            renderNode(node, effectiveSimpleMode, 0, nodeIdx, `node-${nodeIdx}`)
          )}
        </section>
      </div>
    </div>
  );
};

export default BreedingTree;
