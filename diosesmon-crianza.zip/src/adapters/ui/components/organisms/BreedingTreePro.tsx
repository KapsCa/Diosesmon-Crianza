import React, { useState } from 'react';
import {
  ZoomIn,
  ZoomOut,
  RotateCcw,
  Sparkles,
  Flame,
  Coins,
  ShieldCheck,
  Layers,
} from 'lucide-react';
import type { BreedingTree as BreedingTreeType } from '../../../../domain/types/route';

interface BreedingTreeProProps {
  treeData: BreedingTreeType;
  targetSpeciesName?: string;
  simpleMode?: boolean;
  onModeToggle?: (mode: 'simple' | 'advanced') => void;
}

export const BreedingTreePro: React.FC<BreedingTreeProProps> = ({
  treeData,
  targetSpeciesName = 'Pokémon Objetivo',
  simpleMode = false,
  onModeToggle,
}) => {
  const [zoom, setZoom] = useState(100);
  const [selectedGen, setSelectedGen] = useState<'all' | 'p1' | 'f1' | 'f2' | 'target'>('all');

  const { allNodes } = treeData;

  // Calculate generation steps
  const totalGenerations = Math.max(treeData.maxDepth || 1, 3);
  const totalBreedingCycles = Math.max(allNodes.length > 1 ? allNodes.length - 1 : 3, 3);

  // Diosesmon economics
  const daycareFeePerCycle = 20000;
  const powerItemCost = 15000;
  const everstoneCost = 10000;

  // 2 power items consumed per breeding step
  const totalPowerItemsConsumed = totalBreedingCycles * 2;
  const totalDaycareCost = totalBreedingCycles * daycareFeePerCycle;
  const totalItemsCost = totalPowerItemsConsumed * powerItemCost + everstoneCost;
  const totalFinancialCost = totalDaycareCost + totalItemsCost;

  const handleZoomIn = () => setZoom((z) => Math.min(z + 15, 160));
  const handleZoomOut = () => setZoom((z) => Math.max(z - 15, 65));
  const handleZoomReset = () => setZoom(100);

  return (
    <div className="w-full flex flex-col gap-5 p-5 rounded-2xl bg-[#0b0f19] border border-purple-500/25 shadow-2xl">
      {/* Header with Title and Controls */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-800 pb-4">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-xl font-bold font-['Sora'] text-white flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-purple-400" />
              Árbol de Cría IVsMap
            </h2>
            <span className="text-xs px-2.5 py-0.5 rounded-full bg-purple-500/20 text-purple-300 border border-purple-500/40 font-mono">
              Diosesmon Engine
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Linaje visual determinista P1 → F1 → F2 → Target con auditoría de 1x Burn
          </p>
        </div>

        {/* Controls: Mode toggle & Zoom */}
        <div className="flex items-center gap-3 flex-wrap">
          <div className="flex items-center gap-1 p-1 rounded-lg bg-slate-900 border border-slate-800 text-xs">
            <button
              type="button"
              onClick={() => onModeToggle?.('simple')}
              className={`px-2.5 py-1 rounded-md transition-colors ${
                simpleMode
                  ? 'bg-purple-600 text-white font-medium'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              Resumen
            </button>
            <button
              type="button"
              onClick={() => onModeToggle?.('advanced')}
              className={`px-2.5 py-1 rounded-md transition-colors ${
                !simpleMode
                  ? 'bg-purple-600 text-white font-medium'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              Detallado
            </button>
          </div>

          {/* Zoom controls */}
          <div className="flex items-center gap-1 px-2 py-1 rounded-lg bg-slate-900 border border-slate-800 text-xs text-slate-300 font-mono">
            <button
              type="button"
              onClick={handleZoomOut}
              className="p-1 rounded hover:bg-slate-800 text-slate-400 hover:text-white"
              title="Alejar Zoom"
            >
              <ZoomOut className="w-3.5 h-3.5" />
            </button>
            <span className="px-1.5 min-w-[40px] text-center">{zoom}%</span>
            <button
              type="button"
              onClick={handleZoomIn}
              className="p-1 rounded hover:bg-slate-800 text-slate-400 hover:text-white"
              title="Acercar Zoom"
            >
              <ZoomIn className="w-3.5 h-3.5" />
            </button>
            <button
              type="button"
              onClick={handleZoomReset}
              className="p-1 rounded hover:bg-slate-800 text-slate-400 hover:text-white ml-0.5"
              title="Restablecer 100%"
            >
              <RotateCcw className="w-3 h-3" />
            </button>
          </div>
        </div>
      </div>

      {/* Generation Stage Filter Chips */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1 text-xs">
        <span className="text-[11px] text-slate-500 font-mono uppercase flex items-center gap-1 mr-1">
          <Layers className="w-3 h-3" /> Etapa:
        </span>
        <button
          type="button"
          onClick={() => setSelectedGen('all')}
          className={`px-3 py-1 rounded-full font-medium transition-all ${
            selectedGen === 'all'
              ? 'bg-purple-600 text-white shadow-[0_0_10px_rgba(168,85,247,0.3)]'
              : 'bg-slate-900 text-slate-400 hover:text-slate-200 border border-slate-800'
          }`}
        >
          Todo el Linaje ({totalGenerations + 1} etapas)
        </button>
        <button
          type="button"
          onClick={() => setSelectedGen('p1')}
          className={`px-3 py-1 rounded-full font-medium transition-all ${
            selectedGen === 'p1'
              ? 'bg-blue-600 text-white shadow-[0_0_10px_rgba(56,189,248,0.3)]'
              : 'bg-slate-900 text-slate-400 hover:text-slate-200 border border-slate-800'
          }`}
        >
          P1: Progenitores Base
        </button>
        <button
          type="button"
          onClick={() => setSelectedGen('f1')}
          className={`px-3 py-1 rounded-full font-medium transition-all ${
            selectedGen === 'f1'
              ? 'bg-indigo-600 text-white shadow-[0_0_10px_rgba(99,102,241,0.3)]'
              : 'bg-slate-900 text-slate-400 hover:text-slate-200 border border-slate-800'
          }`}
        >
          F1: Consolidación 3x31
        </button>
        <button
          type="button"
          onClick={() => setSelectedGen('f2')}
          className={`px-3 py-1 rounded-full font-medium transition-all ${
            selectedGen === 'f2'
              ? 'bg-purple-600 text-white shadow-[0_0_10px_rgba(168,85,247,0.3)]'
              : 'bg-slate-900 text-slate-400 hover:text-slate-200 border border-slate-800'
          }`}
        >
          F2: Consolidación 4x31
        </button>
        <button
          type="button"
          onClick={() => setSelectedGen('target')}
          className={`px-3 py-1 rounded-full font-medium transition-all ${
            selectedGen === 'target'
              ? 'bg-emerald-600 text-white shadow-[0_0_10px_rgba(16,185,129,0.3)]'
              : 'bg-slate-900 text-slate-400 hover:text-slate-200 border border-slate-800'
          }`}
        >
          Target Final (5x31 / 6x31)
        </button>
      </div>

      {/* Visual Canvas Area with Zoom */}
      <div className="w-full overflow-x-auto rounded-xl bg-[#070a11] border border-slate-800/80 p-6 min-h-[420px] flex items-center justify-center">
        <div
          style={{
            transform: `scale(${zoom / 100})`,
            transformOrigin: 'top center',
            transition: 'transform 0.2s ease',
          }}
          className="w-full flex flex-col items-center gap-8 min-w-[860px]"
        >
          {/* Generation 1: P1 Bases */}
          {(selectedGen === 'all' || selectedGen === 'p1') && (
            <div className="w-full flex flex-col items-center gap-3">
              <div className="flex items-center gap-2">
                <span className="text-[11px] px-2.5 py-0.5 rounded-full bg-sky-950/60 text-sky-300 border border-sky-800/60 font-mono uppercase tracking-wider">
                  Generación P1 • Capturas Silvestres
                </span>
              </div>

              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 w-full max-w-4xl">
                {/* P1-A Father */}
                <div className="p-3.5 rounded-xl bg-[#0f131c] border border-sky-500/40 shadow-lg flex flex-col gap-2">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-white flex items-center gap-1.5">
                      <span className="text-sky-400 font-bold text-sm">♂</span>
                      {targetSpeciesName}
                    </span>
                    <span className="text-[10px] px-1.5 py-0.5 rounded bg-sky-950/50 text-sky-300 font-mono">
                      Padre P1-A
                    </span>
                  </div>
                  {/* IVs */}
                  <div className="grid grid-cols-6 gap-1 text-[10px] font-mono text-center">
                    <span className="bg-emerald-500/20 text-emerald-300 font-bold rounded py-0.5">31</span>
                    <span className="bg-slate-800 text-slate-500 rounded py-0.5">X</span>
                    <span className="bg-slate-800 text-slate-500 rounded py-0.5">X</span>
                    <span className="bg-slate-800 text-slate-500 rounded py-0.5">X</span>
                    <span className="bg-slate-800 text-slate-500 rounded py-0.5">X</span>
                    <span className="bg-slate-800 text-slate-500 rounded py-0.5">X</span>
                  </div>
                  {/* Item Chip */}
                  <div className="mt-1 flex items-center justify-between px-2 py-1 rounded bg-slate-900 border border-slate-800 text-[11px]">
                    <span className="text-purple-300 font-medium flex items-center gap-1">
                      <Flame className="w-3 h-3 text-rose-400" />
                      Pesa Recia (PS)
                    </span>
                    <span className="text-[10px] text-rose-400 font-mono">15,000 Pk$</span>
                  </div>
                </div>

                {/* P1-B Mother */}
                <div className="p-3.5 rounded-xl bg-[#0f131c] border border-pink-500/40 shadow-lg flex flex-col gap-2">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-white flex items-center gap-1.5">
                      <span className="text-pink-400 font-bold text-sm">♀</span>
                      {targetSpeciesName}
                    </span>
                    <span className="text-[10px] px-1.5 py-0.5 rounded bg-pink-950/50 text-pink-300 font-mono">
                      Madre P1-B
                    </span>
                  </div>
                  {/* IVs */}
                  <div className="grid grid-cols-6 gap-1 text-[10px] font-mono text-center">
                    <span className="bg-slate-800 text-slate-500 rounded py-0.5">X</span>
                    <span className="bg-emerald-500/20 text-emerald-300 font-bold rounded py-0.5">31</span>
                    <span className="bg-slate-800 text-slate-500 rounded py-0.5">X</span>
                    <span className="bg-slate-800 text-slate-500 rounded py-0.5">X</span>
                    <span className="bg-slate-800 text-slate-500 rounded py-0.5">X</span>
                    <span className="bg-slate-800 text-slate-500 rounded py-0.5">X</span>
                  </div>
                  {/* Item Chip */}
                  <div className="mt-1 flex items-center justify-between px-2 py-1 rounded bg-slate-900 border border-slate-800 text-[11px]">
                    <span className="text-purple-300 font-medium flex items-center gap-1">
                      <Flame className="w-3 h-3 text-rose-400" />
                      Brazal Recio (Atk)
                    </span>
                    <span className="text-[10px] text-rose-400 font-mono">15,000 Pk$</span>
                  </div>
                </div>

                {/* P1-C Father */}
                <div className="p-3.5 rounded-xl bg-[#0f131c] border border-sky-500/40 shadow-lg flex flex-col gap-2">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-white flex items-center gap-1.5">
                      <span className="text-sky-400 font-bold text-sm">♂</span>
                      {targetSpeciesName}
                    </span>
                    <span className="text-[10px] px-1.5 py-0.5 rounded bg-sky-950/50 text-sky-300 font-mono">
                      Padre P1-C
                    </span>
                  </div>
                  {/* IVs */}
                  <div className="grid grid-cols-6 gap-1 text-[10px] font-mono text-center">
                    <span className="bg-slate-800 text-slate-500 rounded py-0.5">X</span>
                    <span className="bg-slate-800 text-slate-500 rounded py-0.5">X</span>
                    <span className="bg-emerald-500/20 text-emerald-300 font-bold rounded py-0.5">31</span>
                    <span className="bg-slate-800 text-slate-500 rounded py-0.5">X</span>
                    <span className="bg-slate-800 text-slate-500 rounded py-0.5">X</span>
                    <span className="bg-slate-800 text-slate-500 rounded py-0.5">X</span>
                  </div>
                  {/* Item Chip */}
                  <div className="mt-1 flex items-center justify-between px-2 py-1 rounded bg-slate-900 border border-slate-800 text-[11px]">
                    <span className="text-purple-300 font-medium flex items-center gap-1">
                      <Flame className="w-3 h-3 text-rose-400" />
                      Cinto Recio (Def)
                    </span>
                    <span className="text-[10px] text-rose-400 font-mono">15,000 Pk$</span>
                  </div>
                </div>

                {/* P1-D Mother */}
                <div className="p-3.5 rounded-xl bg-[#0f131c] border border-pink-500/40 shadow-lg flex flex-col gap-2">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-white flex items-center gap-1.5">
                      <span className="text-pink-400 font-bold text-sm">♀</span>
                      {targetSpeciesName}
                    </span>
                    <span className="text-[10px] px-1.5 py-0.5 rounded bg-pink-950/50 text-pink-300 font-mono">
                      Madre P1-D
                    </span>
                  </div>
                  {/* IVs */}
                  <div className="grid grid-cols-6 gap-1 text-[10px] font-mono text-center">
                    <span className="bg-slate-800 text-slate-500 rounded py-0.5">X</span>
                    <span className="bg-slate-800 text-slate-500 rounded py-0.5">X</span>
                    <span className="bg-slate-800 text-slate-500 rounded py-0.5">X</span>
                    <span className="bg-slate-800 text-slate-500 rounded py-0.5">X</span>
                    <span className="bg-slate-800 text-slate-500 rounded py-0.5">X</span>
                    <span className="bg-emerald-500/20 text-emerald-300 font-bold rounded py-0.5">31</span>
                  </div>
                  {/* Item Chip */}
                  <div className="mt-1 flex items-center justify-between px-2 py-1 rounded bg-slate-900 border border-slate-800 text-[11px]">
                    <span className="text-purple-300 font-medium flex items-center gap-1">
                      <Flame className="w-3 h-3 text-rose-400" />
                      Franja Recia (Vel)
                    </span>
                    <span className="text-[10px] text-rose-400 font-mono">15,000 Pk$</span>
                  </div>
                </div>
              </div>

              {/* Cruza Connection Node 1 */}
              <div className="flex items-center gap-4 text-xs text-slate-400 my-1">
                <div className="px-3 py-1 rounded-full bg-slate-900 border border-purple-500/30 flex items-center gap-2 font-mono text-[11px]">
                  <Coins className="w-3.5 h-3.5 text-amber-400" />
                  <span>Cruzas P1: 2 ciclos = <strong>40,000 Pk$</strong> guardería + <strong>60,000 Pk$</strong> en 4x Power Items</span>
                </div>
              </div>
            </div>
          )}

          {/* Line connector */}
          <div className="w-0.5 h-6 bg-gradient-to-b from-purple-500 to-indigo-500" />

          {/* Generation 2: F1 2x31 & 3x31 */}
          {(selectedGen === 'all' || selectedGen === 'f1') && (
            <div className="w-full flex flex-col items-center gap-3">
              <div className="flex items-center gap-2">
                <span className="text-[11px] px-2.5 py-0.5 rounded-full bg-indigo-950/60 text-indigo-300 border border-indigo-800/60 font-mono uppercase tracking-wider">
                  Generación F1 • 2x31 y 3x31 Garantizados
                </span>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 w-full max-w-2xl">
                {/* F1-A */}
                <div className="p-4 rounded-xl bg-[#0f131c] border border-indigo-500/50 shadow-xl flex flex-col gap-2.5">
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-bold text-white flex items-center gap-1.5">
                      <span className="text-sky-400 font-bold">♂</span>
                      {targetSpeciesName} (F1-A)
                    </span>
                    <span className="text-xs px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 font-mono font-bold">
                      2x31 (PS + Atk)
                    </span>
                  </div>
                  <div className="grid grid-cols-6 gap-1.5 text-xs font-mono text-center">
                    <span className="bg-emerald-500/20 text-emerald-400 font-bold rounded py-1">31</span>
                    <span className="bg-emerald-500/20 text-emerald-400 font-bold rounded py-1">31</span>
                    <span className="bg-slate-800 text-slate-500 rounded py-1">X</span>
                    <span className="bg-slate-800 text-slate-500 rounded py-1">X</span>
                    <span className="bg-slate-800 text-slate-500 rounded py-1">X</span>
                    <span className="bg-slate-800 text-slate-500 rounded py-1">X</span>
                  </div>
                  <div className="flex items-center justify-between px-2.5 py-1.5 rounded bg-slate-900 border border-slate-800 text-xs">
                    <span className="text-purple-300 font-medium">Equipar: Brazal Recio</span>
                    <span className="text-rose-400 font-mono text-[11px]">15,000 Pk$ (1x Burn)</span>
                  </div>
                </div>

                {/* F1-B */}
                <div className="p-4 rounded-xl bg-[#0f131c] border border-pink-500/50 shadow-xl flex flex-col gap-2.5">
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-bold text-white flex items-center gap-1.5">
                      <span className="text-pink-400 font-bold">♀</span>
                      {targetSpeciesName} (F1-B)
                    </span>
                    <span className="text-xs px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 font-mono font-bold">
                      2x31 (Def + Vel)
                    </span>
                  </div>
                  <div className="grid grid-cols-6 gap-1.5 text-xs font-mono text-center">
                    <span className="bg-slate-800 text-slate-500 rounded py-1">X</span>
                    <span className="bg-slate-800 text-slate-500 rounded py-1">X</span>
                    <span className="bg-emerald-500/20 text-emerald-400 font-bold rounded py-1">31</span>
                    <span className="bg-slate-800 text-slate-500 rounded py-1">X</span>
                    <span className="bg-slate-800 text-slate-500 rounded py-1">X</span>
                    <span className="bg-emerald-500/20 text-emerald-400 font-bold rounded py-1">31</span>
                  </div>
                  <div className="flex items-center justify-between px-2.5 py-1.5 rounded bg-slate-900 border border-slate-800 text-xs">
                    <span className="text-purple-300 font-medium">Equipar: Franja Recia</span>
                    <span className="text-rose-400 font-mono text-[11px]">15,000 Pk$ (1x Burn)</span>
                  </div>
                </div>
              </div>

              {/* Cruza Connection Node 2 */}
              <div className="flex items-center gap-4 text-xs text-slate-400 my-1">
                <div className="px-3 py-1 rounded-full bg-slate-900 border border-purple-500/30 flex items-center gap-2 font-mono text-[11px]">
                  <Coins className="w-3.5 h-3.5 text-amber-400" />
                  <span>Cruza F1: 1 ciclo = <strong>20,000 Pk$</strong> guardería + <strong>30,000 Pk$</strong> consumibles</span>
                </div>
              </div>
            </div>
          )}

          {/* Line connector */}
          <div className="w-0.5 h-6 bg-gradient-to-b from-indigo-500 to-purple-500" />

          {/* Generation 3: F2 Consolidación 4x31 */}
          {(selectedGen === 'all' || selectedGen === 'f2') && (
            <div className="w-full flex flex-col items-center gap-3">
              <div className="flex items-center gap-2">
                <span className="text-[11px] px-2.5 py-0.5 rounded-full bg-purple-950/60 text-purple-300 border border-purple-800/60 font-mono uppercase tracking-wider">
                  Generación F2 • Consolidación 4x31
                </span>
              </div>

              <div className="w-full max-w-lg p-4 rounded-xl bg-[#0f131c] border border-purple-500/60 shadow-xl flex flex-col gap-2.5">
                <div className="flex items-center justify-between">
                  <span className="text-sm font-bold text-white flex items-center gap-1.5">
                    <span className="text-pink-400 font-bold">♀</span>
                    {targetSpeciesName} (Cría F2 Madre)
                  </span>
                  <span className="text-xs px-2.5 py-0.5 rounded bg-emerald-500/25 text-emerald-300 font-mono font-bold">
                    4x31 (PS + Atk + Def + Vel)
                  </span>
                </div>
                <div className="grid grid-cols-6 gap-1.5 text-xs font-mono text-center">
                  <span className="bg-emerald-500/20 text-emerald-400 font-bold rounded py-1">31</span>
                  <span className="bg-emerald-500/20 text-emerald-400 font-bold rounded py-1">31</span>
                  <span className="bg-emerald-500/20 text-emerald-400 font-bold rounded py-1">31</span>
                  <span className="bg-slate-800 text-slate-500 rounded py-1">X</span>
                  <span className="bg-slate-800 text-slate-500 rounded py-1">X</span>
                  <span className="bg-emerald-500/20 text-emerald-400 font-bold rounded py-1">31</span>
                </div>
                <div className="flex items-center justify-between px-2.5 py-1.5 rounded bg-slate-900 border border-slate-800 text-xs">
                  <span className="text-purple-300 font-medium">Equipar: Piedra Eterna (Naturaleza)</span>
                  <span className="text-amber-400 font-mono text-[11px]">10,000 Pk$ (1x Burn)</span>
                </div>
              </div>
            </div>
          )}

          {/* Line connector */}
          <div className="w-0.5 h-6 bg-gradient-to-b from-purple-500 to-emerald-500" />

          {/* Target Final Generation */}
          {(selectedGen === 'all' || selectedGen === 'target') && (
            <div className="w-full flex flex-col items-center gap-3">
              <div className="flex items-center gap-2">
                <span className="text-xs px-3 py-1 rounded-full bg-emerald-950/80 text-emerald-300 border border-emerald-500/60 font-mono uppercase tracking-wider flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5 text-emerald-400" />
                  Target Final Competitivo Diosesmon
                </span>
              </div>

              <div className="w-full max-w-xl p-5 rounded-2xl bg-gradient-to-b from-[#0f172a] to-[#0a1220] border-2 border-emerald-500/70 shadow-[0_0_25px_rgba(16,185,129,0.25)] flex flex-col gap-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="text-base font-bold text-white font-['Sora']">
                      {targetSpeciesName}
                    </span>
                    <span className="text-xs px-2 py-0.5 rounded bg-purple-500/20 text-purple-300 border border-purple-500/40 font-mono">
                      Competitivo Listo
                    </span>
                  </div>
                  <span className="text-sm px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 font-mono font-extrabold">
                    5x31 / 6x31
                  </span>
                </div>

                <div className="grid grid-cols-6 gap-2 text-xs font-mono text-center">
                  <div className="p-2 rounded bg-emerald-950/40 border border-emerald-500/40 flex flex-col items-center">
                    <span className="text-[10px] text-slate-400 uppercase">PS</span>
                    <span className="text-emerald-400 font-bold text-sm">31</span>
                  </div>
                  <div className="p-2 rounded bg-emerald-950/40 border border-emerald-500/40 flex flex-col items-center">
                    <span className="text-[10px] text-slate-400 uppercase">Atk</span>
                    <span className="text-emerald-400 font-bold text-sm">31</span>
                  </div>
                  <div className="p-2 rounded bg-emerald-950/40 border border-emerald-500/40 flex flex-col items-center">
                    <span className="text-[10px] text-slate-400 uppercase">Def</span>
                    <span className="text-emerald-400 font-bold text-sm">31</span>
                  </div>
                  <div className="p-2 rounded bg-slate-900 border border-slate-800 flex flex-col items-center">
                    <span className="text-[10px] text-slate-400 uppercase">SpA</span>
                    <span className="text-slate-400 font-bold text-sm">X</span>
                  </div>
                  <div className="p-2 rounded bg-emerald-950/40 border border-emerald-500/40 flex flex-col items-center">
                    <span className="text-[10px] text-slate-400 uppercase">SpD</span>
                    <span className="text-emerald-400 font-bold text-sm">31</span>
                  </div>
                  <div className="p-2 rounded bg-emerald-950/40 border border-emerald-500/40 flex flex-col items-center">
                    <span className="text-[10px] text-slate-400 uppercase">Vel</span>
                    <span className="text-emerald-400 font-bold text-sm">31</span>
                  </div>
                </div>

                <div className="flex items-center justify-between text-xs text-slate-300 pt-1 border-t border-slate-800">
                  <span className="text-emerald-400 flex items-center gap-1.5 font-medium">
                    <ShieldCheck className="w-4 h-4" />
                    Ruta Matemática Garantizada (0% RNG)
                  </span>
                  <span className="font-mono text-slate-400">
                    Costo Acumulado: <strong className="text-amber-300">{totalFinancialCost.toLocaleString()} Pk$</strong>
                  </span>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Financial Breakdown & Consumables Audit Table */}
      <div className="mt-2 p-4 rounded-xl bg-[#0f131c] border border-slate-800 flex flex-col gap-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2 text-sm font-semibold text-white">
            <Coins className="w-4 h-4 text-amber-400" />
            <span>Auditoría Financiera & Lista de Compras al NPC</span>
          </div>
          <span className="text-xs text-slate-400 font-mono">
            {totalBreedingCycles} Cruzas Totales
          </span>
        </div>

        {/* Warning banner about 1x burn rule */}
        <div className="p-3 rounded-lg bg-rose-950/20 border border-rose-500/30 flex items-start gap-2.5 text-xs text-rose-300">
          <Flame className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
          <div>
            <strong>Regla Inviolable de Servidor (1x Burn):</strong> Los Power Items y la Piedra Eterna se queman irrevocablemente tras cada cruza. Todos los ítems en la tabla deben comprarse por adelantado en el NPC de Diosesmon.
          </div>
        </div>

        {/* Table */}
        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400 uppercase font-mono text-[11px]">
                <th className="py-2 px-3">Concepto / Ítem NPC</th>
                <th className="py-2 px-3">Efecto Táctico</th>
                <th className="py-2 px-3 text-center">Unidades (1x Burn)</th>
                <th className="py-2 px-3 text-right">Precio Unitario</th>
                <th className="py-2 px-3 text-right">Subtotal Pk$</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 font-mono">
              <tr className="hover:bg-slate-900/40">
                <td className="py-2.5 px-3 font-sans font-medium text-white flex items-center gap-2">
                  <Coins className="w-3.5 h-3.5 text-amber-400" />
                  Tarifas de Guardería (Ciclos de cruce)
                </td>
                <td className="py-2.5 px-3 text-slate-400 font-sans">Cuota fija por ciclo de eclosión</td>
                <td className="py-2.5 px-3 text-center text-slate-200">{totalBreedingCycles}x</td>
                <td className="py-2.5 px-3 text-right text-slate-400">20,000 Pk$</td>
                <td className="py-2.5 px-3 text-right text-amber-300 font-bold">
                  {totalDaycareCost.toLocaleString()} Pk$
                </td>
              </tr>
              <tr className="hover:bg-slate-900/40">
                <td className="py-2.5 px-3 font-sans font-medium text-white flex items-center gap-2">
                  <Flame className="w-3.5 h-3.5 text-rose-400" />
                  Power Items Recios (Pesa, Brazal, Cinto, etc.)
                </td>
                <td className="py-2.5 px-3 text-slate-400 font-sans">Bloqueo determinista de 2 IVs por cruza</td>
                <td className="py-2.5 px-3 text-center text-slate-200">{totalPowerItemsConsumed}x</td>
                <td className="py-2.5 px-3 text-right text-slate-400">15,000 Pk$</td>
                <td className="py-2.5 px-3 text-right text-rose-300 font-bold">
                  {(totalPowerItemsConsumed * powerItemCost).toLocaleString()} Pk$
                </td>
              </tr>
              <tr className="hover:bg-slate-900/40">
                <td className="py-2.5 px-3 font-sans font-medium text-white flex items-center gap-2">
                  <Flame className="w-3.5 h-3.5 text-purple-400" />
                  Piedra Eterna
                </td>
                <td className="py-2.5 px-3 text-slate-400 font-sans">Herencia del 100% de la naturaleza deseada</td>
                <td className="py-2.5 px-3 text-center text-slate-200">1x</td>
                <td className="py-2.5 px-3 text-right text-slate-400">10,000 Pk$</td>
                <td className="py-2.5 px-3 text-right text-purple-300 font-bold">
                  {everstoneCost.toLocaleString()} Pk$
                </td>
              </tr>
              <tr className="bg-purple-950/20 font-bold text-sm">
                <td colSpan={4} className="py-3 px-3 text-white font-sans">
                  COSTO TOTAL DE PRODUCCIÓN (Pk$ Requeridos):
                </td>
                <td className="py-3 px-3 text-right text-emerald-400 font-bold text-base">
                  {totalFinancialCost.toLocaleString()} Pk$
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default BreedingTreePro;
