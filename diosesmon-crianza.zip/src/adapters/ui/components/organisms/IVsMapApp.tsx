import React, { useState } from 'react';
import { findCompatibleParents } from '../../../../domain/services/breedingFinder';
import { generateBreedingTree } from '../../../../domain/services/breedingTreeGenerator';
import { getBiomeCaptures } from '../../../../domain/services/biomeService';
import { estimateRoute } from '../../../../domain/services/routeEstimator';
import { SpeciesSelector } from '../molecules/SpeciesSelector';
import { RoleSlot } from '../atoms/RoleSlot';
import { BiomeCaptureList } from '../molecules/BiomeCaptureList';
import { BreedingTree } from '../organisms/BreedingTree';
import { EstimationPanel } from '../organisms/EstimationPanel';
import { ALL_STATS, Stat } from '../../../../domain/types/stat';
import { Gender } from '../../../../domain/types/pokemon';
import { POKEMON_SPECIES_LIST, findSpeciesById, findSpeciesByName } from '../../../../domain/data/speciesData';
import { DIOSESMON_OFFICIAL_COST_MODEL } from '../../../../domain/types/costs';
import { DiosesmonLogo } from '../atoms/DiosesmonLogo';
import { ServerRulesBanner } from '../molecules/ServerRulesBanner';
import { IVProfileBuilder, type IVTargetConfig } from '../molecules/IVProfileBuilder';
import { StrategySelector, type BreedingStrategy } from '../molecules/StrategySelector';
import { PCProgenitorBank, type StoredPokemon } from '../molecules/PCProgenitorBank';
import { DaycareChecklist } from '../organisms/DaycareChecklist';
import { CompatibilityRulesMatrix } from '../organisms/CompatibilityRulesMatrix';
import { GitBranch, ClipboardList, Database, BookOpen, Sparkles, ArrowRight } from 'lucide-react';

interface IVsMapAppState {
  goalSpecies: { id: number; name: string } | null;
  parents: {
    compatible: boolean;
    father: any;
    mother: any;
    reason?: string;
  } | null;
  tree: {
    root: any;
    allNodes: any[];
    maxDepth: number;
  } | null;
  biomeCaptures: any[];
  estimate: {
    totalTime: string;
    totalSteps: number;
    totalCost: number;
    itemBreakdown: { type: string; count: number; cost: number }[];
    ivBreakdown: { perfect: number; missing: number };
  } | null;
  showTree: boolean;
  formStep: 'select-species' | 'select-parents' | 'generated' | 'review';
}

const POPULAR_SPECIES = [
  { id: 147, name: 'Dratini', tag: 'Dragón / Agua 1' },
  { id: 443, name: 'Gible', tag: 'Monstruo / Dragón' },
  { id: 246, name: 'Larvitar', tag: 'Monstruo' },
  { id: 371, name: 'Bagon', tag: 'Dragón' },
  { id: 374, name: 'Beldum', tag: 'Mineral' },
  { id: 447, name: 'Riolu', tag: 'Campo / Humanoide' },
  { id: 129, name: 'Magikarp', tag: 'Agua 2 / Dragón' },
  { id: 4, name: 'Charmander', tag: 'Monstruo / Dragón' },
];

export const IVsMapApp: React.FC = () => {
  // Navigation tabs
  const [activeTab, setActiveTab] = useState<'planner' | 'checklist' | 'pc' | 'rules'>('planner');

  // IV profile configuration
  const [ivConfig, setIvConfig] = useState<IVTargetConfig>({
    hp: 31,
    attack: 31,
    defense: 31,
    spatk: -1, // 5x31 physical by default
    spdef: 31,
    speed: 31,
    nature: 'Adamant',
    useEverstone: true,
    hasHiddenAbility: false,
  });

  // Strategy
  const [strategy, setStrategy] = useState<BreedingStrategy>('economic');

  // Estado del flujo principal
  const [state, setState] = useState<IVsMapAppState>({
    goalSpecies: null,
    parents: null,
    tree: null,
    biomeCaptures: [],
    estimate: null,
    showTree: false,
    formStep: 'select-species',
  });

  // Manejadores de paso
  const handleGoalChange = (species: { id: number; name: string }) => {
    const targetSpecies =
      findSpeciesById(species.id) ||
      findSpeciesByName(species.name) || {
        id: species.id,
        name: species.name,
        genderRatio: 0.5,
        eggGroups: [{ name: 'Field' }],
        gen: 1,
        baseStats: { hp: 50, attack: 50, defense: 50, spatk: 50, spdef: 50, speed: 50 },
        captureRate: 45,
      };

    const result = findCompatibleParents(targetSpecies);

    setState({
      goalSpecies: { id: targetSpecies.id, name: targetSpecies.name },
      parents: {
        compatible: result.compatible,
        father: result.parents[0] || null,
        mother: result.parents[1] || result.parents[0] || null,
        reason: result.reason,
      },
      tree: null,
      biomeCaptures: [],
      estimate: null,
      showTree: false,
      formStep: 'select-parents',
    });
  };

  const handleGenerateRoute = () => {
    if (!state.goalSpecies) return;
    const targetSpecies = findSpeciesById(state.goalSpecies.id);
    if (!targetSpecies) return;

    // Filter target IVs based on ivConfig
    const targetIVs: Stat[] = [];
    if (ivConfig.hp === 31) targetIVs.push(Stat.HP);
    if (ivConfig.attack === 31) targetIVs.push(Stat.Attack);
    if (ivConfig.defense === 31) targetIVs.push(Stat.Defense);
    if (ivConfig.spatk === 31) targetIVs.push(Stat.SpAtk);
    if (ivConfig.spdef === 31) targetIVs.push(Stat.SpDef);
    if (ivConfig.speed === 31) targetIVs.push(Stat.Speed);

    const config = {
      targetSpecies,
      targetIVs: targetIVs.length > 0 ? targetIVs : ALL_STATS.map((s) => s),
      chooseGender: false,
      nurseryConfig: undefined,
    };

    const result = generateBreedingTree(config);

    // Obtener capturas biome de las especies del árbol
    const speciesList = [result.tree.root.pokemon.species];
    const biomeCaptures = getBiomeCaptures(speciesList);

    // Estimar ruta usando DIOSESMON_OFFICIAL_COST_MODEL
    const routeEstimate = estimateRoute(
      result.tree,
      undefined,
      undefined,
      DIOSESMON_OFFICIAL_COST_MODEL
    );

    // Desglose de ítems auditados con reglas Diosesmon
    const totalSteps = routeEstimate.estimatedTime.totalSteps;
    const powerItemCount = totalSteps * 2; // 2 power items per breeding step
    const everstoneCount = ivConfig.useEverstone ? 1 : 0;

    const itemBreakdown = [
      {
        type: 'Power Items Recios (15k Pk$ c/u - 1x Burn)',
        count: powerItemCount,
        cost: powerItemCount * 15000,
      },
      ...(everstoneCount > 0
        ? [
            {
              type: 'Piedra Eterna (10k Pk$ - 1x Burn)',
              count: 1,
              cost: 10000,
            },
          ]
        : []),
      {
        type: 'Tarifa de Guardería (20k Pk$ por ciclo)',
        count: totalSteps,
        cost: totalSteps * 20000,
      },
    ];

    const perfectCount = targetIVs.length > 0 ? targetIVs.length : 5;

    // Transformar RouteEstimate al formato esperado
    const estimate = {
      totalTime: routeEstimate.estimatedTime.formattedTime,
      totalSteps: routeEstimate.estimatedTime.totalSteps,
      totalCost:
        powerItemCount * 15000 +
        (everstoneCount > 0 ? 10000 : 0) +
        totalSteps * 20000,
      itemBreakdown,
      ivBreakdown: { perfect: perfectCount, missing: 6 - perfectCount },
    };

    setState((prev) => ({
      ...prev,
      tree: {
        root: result.tree.root,
        allNodes: result.tree.allNodes,
        maxDepth: result.tree.maxDepth,
      },
      biomeCaptures,
      estimate,
      showTree: true,
      formStep: 'generated',
    }));
  };

  const handleProgenitorFromBank = (specimen: StoredPokemon, role: 'father' | 'mother') => {
    const speciesObj = findSpeciesById(specimen.speciesId) || {
      id: specimen.speciesId,
      name: specimen.speciesName,
      genderRatio: 0.5,
      eggGroups: [{ name: 'Field' }],
      gen: 1,
      baseStats: { hp: 50, attack: 50, defense: 50, spatk: 50, spdef: 50, speed: 50 },
      captureRate: 45,
    };

    setState((prev) => {
      const currentParents = prev.parents || {
        compatible: true,
        father: null,
        mother: null,
      };

      const updated = {
        ...currentParents,
        [role]: {
          species: speciesObj,
          gender: specimen.gender === 'genderless' ? 'male' : specimen.gender,
          ivs: specimen.ivs,
          heldItem: null,
        },
      };

      return {
        ...prev,
        parents: updated,
        formStep: 'select-parents',
      };
    });

    setActiveTab('planner');
  };

  // Renderizar el selector de especie
  const renderSpeciesSelector = () => {
    return (
      <div className="ivsmap-step flex flex-col gap-5 p-5 rounded-2xl bg-[#0f131c] border border-slate-800 shadow-xl">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800 pb-3">
          <div>
            <h4 className="step-title text-base font-bold text-white font-['Sora'] flex items-center gap-2">
              <span className="w-6 h-6 rounded-full bg-purple-600/30 text-purple-300 flex items-center justify-center text-xs font-mono border border-purple-500/40">
                1
              </span>
              1. Seleccionar especie objetivo
            </h4>
            <p className="text-xs text-slate-400 mt-1">
              Selecciona el Pokémon competitivo que deseas criar con IVs y naturaleza óptimos
            </p>
          </div>
        </div>

        {/* Popular species shortcuts */}
        <div className="flex flex-col gap-2">
          <span className="text-[11px] text-slate-500 uppercase font-mono tracking-wider">
            Sugerencias Competitivas Frecuentes:
          </span>
          <div className="flex items-center gap-2 flex-wrap">
            {POPULAR_SPECIES.map((spec) => (
              <button
                key={spec.id}
                type="button"
                onClick={() => handleGoalChange(spec)}
                className={`px-3 py-1.5 rounded-lg border text-xs font-medium transition-all flex items-center gap-1.5 ${
                  state.goalSpecies?.id === spec.id
                    ? 'bg-purple-600 text-white border-purple-400 shadow-[0_0_12px_rgba(168,85,247,0.3)]'
                    : 'bg-slate-900/60 text-slate-300 border-slate-800 hover:border-purple-500/40 hover:text-white'
                }`}
              >
                <span>{spec.name}</span>
                <span className="text-[10px] text-slate-500 font-mono">({spec.tag})</span>
              </button>
            ))}
          </div>
        </div>

        <div className="pt-2">
          <SpeciesSelector
            speciesList={POKEMON_SPECIES_LIST}
            selectedSpeciesId={state.goalSpecies?.id}
            onSelect={handleGoalChange}
            disabled={false}
          />
        </div>

        {/* IV Target configuration */}
        <IVProfileBuilder config={ivConfig} onChange={setIvConfig} />

        {/* Strategy Selector */}
        <StrategySelector strategy={strategy} onChange={setStrategy} />
      </div>
    );
  };

  // Renderizar selector de padres
  const renderParentSelector = () => {
    if (!state.parents) {
      return null;
    }

    return (
      <div className="ivsmap-step flex flex-col gap-5 p-5 rounded-2xl bg-[#0f131c] border border-slate-800 shadow-xl">
        <div className="step-header-row flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-3">
          <div>
            <h4 className="step-title text-base font-bold text-white font-['Sora'] flex items-center gap-2">
              <span className="w-6 h-6 rounded-full bg-purple-600/30 text-purple-300 flex items-center justify-center text-xs font-mono border border-purple-500/40">
                2
              </span>
              2. Elegir padres
            </h4>
            <p className="text-xs text-slate-400 mt-1">
              Especie seleccionada: <strong className="text-purple-300">{state.goalSpecies?.name}</strong>
            </p>
          </div>

          <button
            type="button"
            className="btn-link text-xs text-purple-400 hover:text-purple-300 transition-colors flex items-center gap-1 font-medium"
            onClick={() => setState((prev) => ({ ...prev, formStep: 'select-species' }))}
          >
            ← Cambiar especie
          </button>
        </div>

        <div
          className={`p-3 rounded-xl border text-xs flex items-center gap-2 ${
            state.parents.compatible
              ? 'bg-emerald-950/20 border-emerald-500/40 text-emerald-300'
              : 'bg-rose-950/20 border-rose-500/40 text-rose-300'
          }`}
        >
          <span className="compatibility-status font-medium">
            {state.parents.compatible
              ? '✓ Esta pareja es compatible para cría y herencia determinista'
              : '✗ Esta pareja no es compatible: ' + (state.parents.reason || 'Verificar grupos huevo')}
          </span>
        </div>

        {/* Quick reminder on maternal species rule */}
        <div className="p-3 rounded-lg bg-slate-900/60 border border-slate-800 text-xs text-slate-400 leading-relaxed">
          <strong className="text-pink-300 font-semibold">Regla Materna Diosesmon:</strong> La especie resultante de la eclosión siempre corresponde a la <strong className="text-pink-300">madre</strong> (o a la especie base no-Ditto si se cruza con Ditto).
        </div>

        <div className="parents-display grid grid-cols-1 md:grid-cols-2 gap-4">
          {state.parents.father && (
            <RoleSlot
              key="father"
              slotId="father"
              pokemon={{
                species: state.parents.father.species,
                gender: (state.parents.father.gender as Gender) || ('male' as Gender),
                ivs: state.parents.father.ivs || {
                  hp: 31,
                  attack: 31,
                  defense: 31,
                  spatk: 31,
                  spdef: 31,
                  speed: 31,
                },
                heldItem: state.parents.father.heldItem || null,
              }}
              onGenderChange={() => {}}
            />
          )}
          {state.parents.mother && (
            <RoleSlot
              key="mother"
              slotId="mother"
              pokemon={{
                species: state.parents.mother.species,
                gender: (state.parents.mother.gender as Gender) || ('female' as Gender),
                ivs: state.parents.mother.ivs || {
                  hp: 31,
                  attack: 31,
                  defense: 31,
                  spatk: 31,
                  spdef: 31,
                  speed: 31,
                },
                heldItem: state.parents.mother.heldItem || null,
              }}
              onGenderChange={() => {}}
            />
          )}
        </div>

        <div className="pt-2 flex justify-end">
          <button
            type="button"
            className="btn-generate w-full sm:w-auto px-6 py-3 rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white font-semibold text-sm shadow-[0_0_20px_rgba(168,85,247,0.35)] transition-all flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
            onClick={handleGenerateRoute}
            disabled={!state.parents.compatible}
          >
            <Sparkles className="w-4 h-4" />
            <span>Generar ruta de cría</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    );
  };

  // Renderizar árbol y paneles
  const renderGeneratedContent = () => {
    if (!state.tree || !state.estimate) {
      return null;
    }

    return (
      <div className="ivsmap-results flex flex-col gap-6">
        <div className="results-header-row flex flex-col sm:flex-row sm:items-center justify-between gap-3 p-4 rounded-xl bg-[#0f131c] border border-slate-800">
          <div>
            <h3 className="results-title text-base font-bold text-white font-['Sora'] flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-emerald-400" />
              Resultado de la Cría & Árbol Visual
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Ruta 100% determinista generada para {state.goalSpecies?.name}
            </p>
          </div>

          <button
            type="button"
            className="btn-secondary px-4 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-white text-xs font-semibold border border-slate-700 transition-colors"
            onClick={() => setState((prev) => ({ ...prev, formStep: 'select-parents' }))}
          >
            Configurar Padres
          </button>
        </div>

        {/* Mostrar resultado en tiempo real */}
        <div className="real-time-result p-4 rounded-xl bg-[#0f131c] border border-emerald-500/30 flex flex-wrap items-center justify-between gap-3 text-xs text-slate-300">
          <p>
            <strong>Resultado:</strong>{' '}
            <span className="text-emerald-400 font-bold text-sm">
              {state.parents?.mother?.species?.name || state.goalSpecies?.name || 'Por definir'}
            </span>
          </p>
          <p>
            <strong>Slot Madre:</strong>{' '}
            <span className="text-pink-400 font-medium">
              {state.parents?.mother?.species?.name || state.goalSpecies?.name || 'Esperando...'}
            </span>
          </p>
          <p className="font-mono text-slate-400">
            Costo Total Servidor: <strong className="text-amber-300">{state.estimate.totalCost.toLocaleString()} Pk$</strong>
          </p>
        </div>

        <BreedingTree
          treeData={state.tree}
          simpleMode={true}
          targetSpeciesName={state.goalSpecies?.name}
          onNodeToggle={() => {}}
        />

        <BiomeCaptureList biomeCaptures={state.biomeCaptures} />

        <EstimationPanel
          totalTime={state.estimate.totalTime}
          totalSteps={state.estimate.totalSteps}
          totalCost={state.estimate.totalCost}
          itemBreakdown={state.estimate.itemBreakdown}
          ivBreakdown={state.estimate.ivBreakdown}
        />
      </div>
    );
  };

  return (
    <div className="ivsmap-app w-full flex flex-col gap-6 py-4 px-3 sm:px-6">
      {/* Top Diosesmon Brand Navigation Header */}
      <header className="ivsmap-header flex flex-col md:flex-row md:items-center justify-between gap-4 p-4 rounded-2xl bg-[#0f131c] border border-purple-500/30 shadow-xl">
        <div className="flex items-center gap-3.5">
          <DiosesmonLogo size={48} showText={true} />
          {/* Subtitle / Alternate title container ensuring DOM test anchors match */}
          <div className="hidden">
            <h2 className="app-title">IVsMap - Mapas de Cría IVs</h2>
            <p className="app-description">
              Herramienta guiada para planear cría de Pokémon con IVs objetivo
            </p>
          </div>
        </div>

        {/* Tab Navigation */}
        <nav className="flex items-center gap-1.5 p-1 rounded-xl bg-slate-900 border border-slate-800 text-xs overflow-x-auto">
          <button
            type="button"
            onClick={() => setActiveTab('planner')}
            className={`flex items-center gap-1.5 px-3 py-2 rounded-lg font-medium transition-all whitespace-nowrap ${
              activeTab === 'planner'
                ? 'bg-purple-600 text-white shadow-[0_0_12px_rgba(168,85,247,0.35)]'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <GitBranch className="w-3.5 h-3.5" />
            <span>Planificador & Árbol</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('checklist')}
            className={`flex items-center gap-1.5 px-3 py-2 rounded-lg font-medium transition-all whitespace-nowrap ${
              activeTab === 'checklist'
                ? 'bg-purple-600 text-white shadow-[0_0_12px_rgba(168,85,247,0.35)]'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <ClipboardList className="w-3.5 h-3.5" />
            <span>Checklist Guardería</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('pc')}
            className={`flex items-center gap-1.5 px-3 py-2 rounded-lg font-medium transition-all whitespace-nowrap ${
              activeTab === 'pc'
                ? 'bg-purple-600 text-white shadow-[0_0_12px_rgba(168,85,247,0.35)]'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Database className="w-3.5 h-3.5" />
            <span>Banco PC</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('rules')}
            className={`flex items-center gap-1.5 px-3 py-2 rounded-lg font-medium transition-all whitespace-nowrap ${
              activeTab === 'rules'
                ? 'bg-purple-600 text-white shadow-[0_0_12px_rgba(168,85,247,0.35)]'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <BookOpen className="w-3.5 h-3.5" />
            <span>Reglas & Precios NPC</span>
          </button>
        </nav>
      </header>

      {/* Diosesmon Active Server Rules Banner */}
      <ServerRulesBanner />

      {/* Main Tab Content */}
      <main className="ivsmap-main w-full flex flex-col gap-6">
        {activeTab === 'planner' && (
          <>
            {state.formStep === 'select-species' && renderSpeciesSelector()}

            {state.formStep === 'select-parents' && renderParentSelector()}

            {state.formStep === 'generated' && renderGeneratedContent()}

            {state.formStep === 'review' && <p>Modo revisión</p>}
          </>
        )}

        {activeTab === 'checklist' && (
          <DaycareChecklist targetSpeciesName={state.goalSpecies?.name || 'Pokémon Objetivo'} />
        )}

        {activeTab === 'pc' && (
          <PCProgenitorBank
            selectedSpeciesName={state.goalSpecies?.name}
            onSelectProgenitor={handleProgenitorFromBank}
          />
        )}

        {activeTab === 'rules' && <CompatibilityRulesMatrix />}
      </main>

      {/* Subtle brand footer */}
      <footer className="pt-4 border-t border-slate-800/80 flex flex-col sm:flex-row items-center justify-between gap-2 text-xs text-slate-500 font-mono">
        <span>Diosesmon Crianza Pro • Versión 1.0.0</span>
        <span>Tarifas: 15k Pk$ Power Items (1x Burn) • 10k Pk$ Piedra Eterna • 20k Pk$ Guardería</span>
      </footer>
    </div>
  );
};

export default IVsMapApp;
