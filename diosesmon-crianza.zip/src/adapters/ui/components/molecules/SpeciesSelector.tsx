import React, { useState } from 'react';

/**
 * SpeciesSelector - Componente molécula que permite buscar y seleccionar una especie Pokémon.
 *
 * Features:
 * - Permite escribir el nombre de la especie en un campo de texto con autocompletado en tiempo real
 * - Renderiza un <select> sincronizado con todas las especies proporcionadas
 * - Opcional filtro por eggGroup (solo muestra species que tienen ese grupo huevo)
 * - Muestra sugerencias interactivas basadas en lo que el usuario escribe
 *
 * @param speciesList - Lista de especies Pokémon disponibles
 * @param eggGroupFilter - Opcional: filtrar species por este grupo huevo
 * @param onSelect - Callback cuando se selecciona una especie
 * @param disabled - Si true, deshabilita el selector
 * @param selectedSpeciesId - Opcional: ID de la especie actualmente seleccionada
 */
interface SpeciesSelectorProps {
  speciesList: {
    id: number;
    name: string;
    genderRatio: number;
    eggGroups: { name: string }[];
    gen: number;
    baseStats: {
      hp: number;
      attack: number;
      defense: number;
      spatk: number;
      spdef: number;
      speed: number;
    };
    captureRate: number;
  }[];
  eggGroupFilter?: string;
  onSelect?: (species: { id: number; name: string }) => void;
  disabled?: boolean;
  selectedSpeciesId?: number;
}

export const SpeciesSelector: React.FC<SpeciesSelectorProps> = ({
  speciesList,
  eggGroupFilter,
  onSelect,
  disabled,
  selectedSpeciesId,
}) => {
  const [searchTerm, setSearchTerm] = useState<string>('');
  const [selectedId, setSelectedId] = useState<number | ''>(selectedSpeciesId ?? '');

  // Filtrar species por eggGroup si se proporciona
  const baseFilteredSpecies = eggGroupFilter
    ? speciesList.filter((species) =>
        species.eggGroups.some((group) => group.name === eggGroupFilter)
      )
    : speciesList;

  // Filtrar especies por búsqueda de texto
  const filteredSpecies = searchTerm.trim()
    ? baseFilteredSpecies.filter((species) =>
        species.name.toLowerCase().includes(searchTerm.trim().toLowerCase())
      )
    : baseFilteredSpecies;

  const handleSelectSpecies = (species: { id: number; name: string }) => {
    setSelectedId(species.id);
    setSearchTerm(species.name);
    if (onSelect) {
      onSelect({ id: species.id, name: species.name });
    }
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = e.target.value;
    setSearchTerm(val);

    // Si el usuario escribe exactamente el nombre de una especie, seleccionarla
    const exactMatch = baseFilteredSpecies.find(
      (s) => s.name.toLowerCase() === val.trim().toLowerCase()
    );
    if (exactMatch) {
      setSelectedId(exactMatch.id);
      if (onSelect) {
        onSelect({ id: exactMatch.id, name: exactMatch.name });
      }
    } else if (selectedId !== '') {
      setSelectedId('');
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      if (filteredSpecies.length > 0) {
        handleSelectSpecies(filteredSpecies[0]);
      } else if (searchTerm.trim() && onSelect) {
        // Permitir nombre personalizado si no se encuentra en la lista
        handleSelectSpecies({ id: 99999, name: searchTerm.trim() });
      }
    }
  };

  return (
    <div className="species-selector">
      <label htmlFor="species-selector">Especie Pokémon</label>

      {/* Campo de texto para escribir la especie directamente */}
      <div className="species-search-box">
        <input
          id="species-search-input"
          type="text"
          className="species-text-input"
          placeholder="Escribe el nombre del Pokémon (ej. Pikachu, Lucario...)"
          value={searchTerm}
          onChange={handleInputChange}
          onKeyDown={handleKeyDown}
          disabled={disabled}
          autoComplete="off"
        />
        {searchTerm && (
          <button
            type="button"
            className="species-clear-btn"
            onClick={() => {
              setSearchTerm('');
              setSelectedId('');
            }}
            aria-label="Borrar búsqueda"
          >
            ✕
          </button>
        )}
      </div>

      {/* Menú desplegable estándar sincronizado */}
      <select
        id="species-selector"
        className="species-select"
        value={selectedId}
        onChange={(e) => {
          const id = Number(e.target.value);
          const chosen = speciesList.find((s) => s.id === id);
          if (chosen) {
            handleSelectSpecies(chosen);
          }
        }}
        disabled={disabled}
      >
        <option value="" disabled>
          Seleccioná una especie
        </option>
        {filteredSpecies.map((species) => (
          <option key={species.id} value={species.id}>
            {species.name}
          </option>
        ))}
      </select>

      {/* Sugerencias interactivas rápidas si hay término de búsqueda */}
      {searchTerm.trim() && filteredSpecies.length > 0 && (
        <div className="species-quick-matches" aria-label="Sugerencias de especies">
          <span className="quick-matches-label">Coincidencias:</span>
          <div className="quick-matches-chips">
            {filteredSpecies.slice(0, 6).map((species) => (
              <button
                key={species.id}
                type="button"
                className={`quick-match-chip ${selectedId === species.id ? 'active' : ''}`}
                onClick={() => handleSelectSpecies(species)}
              >
                {species.name}
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default SpeciesSelector;