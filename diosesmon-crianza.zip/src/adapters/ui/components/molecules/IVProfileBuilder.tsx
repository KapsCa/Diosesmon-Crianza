import React from 'react';
import { Sparkles, Zap, Shield, Heart, Sword, Gauge, Wand2 } from 'lucide-react';

export interface IVTargetConfig {
  hp: number; // 31 | 0 | -1 (X / irrelevant)
  attack: number;
  defense: number;
  spatk: number;
  spdef: number;
  speed: number;
  nature: string;
  useEverstone: boolean;
  hasHiddenAbility: boolean;
}

interface IVProfileBuilderProps {
  config: IVTargetConfig;
  onChange: (newConfig: IVTargetConfig) => void;
}

export const COMMON_NATURES = [
  { name: 'Adamant', es: 'Firme', plus: 'Ataque', minus: 'At. Esp.' },
  { name: 'Jolly', es: 'Alegre', plus: 'Velocidad', minus: 'At. Esp.' },
  { name: 'Modest', es: 'Modesta', plus: 'At. Esp.', minus: 'Ataque' },
  { name: 'Timid', es: 'Miedosa', plus: 'Velocidad', minus: 'Ataque' },
  { name: 'Bold', es: 'Osada', plus: 'Defensa', minus: 'Ataque' },
  { name: 'Calm', es: 'Serena', plus: 'Def. Esp.', minus: 'Ataque' },
  { name: 'Impish', es: 'Agitada', plus: 'Defensa', minus: 'At. Esp.' },
  { name: 'Careful', es: 'Cauta', plus: 'Def. Esp.', minus: 'At. Esp.' },
  { name: 'Brave', es: 'Audaz', plus: 'Ataque', minus: 'Velocidad' },
  { name: 'Quiet', es: 'Mansa', plus: 'At. Esp.', minus: 'Velocidad' },
];

export const IVProfileBuilder: React.FC<IVProfileBuilderProps> = ({ config, onChange }) => {
  // Preset handlers
  const applyPreset = (preset: '5x31_physical' | '5x31_special' | '6x31_absolute' | 'trick_room') => {
    switch (preset) {
      case '5x31_physical':
        onChange({
          ...config,
          hp: 31,
          attack: 31,
          defense: 31,
          spatk: -1, // X
          spdef: 31,
          speed: 31,
          nature: config.nature || 'Adamant',
        });
        break;
      case '5x31_special':
        onChange({
          ...config,
          hp: 31,
          attack: 0, // 0 Atk for minimum Foul Play / confusion
          defense: 31,
          spatk: 31,
          spdef: 31,
          speed: 31,
          nature: config.nature || 'Modest',
        });
        break;
      case '6x31_absolute':
        onChange({
          ...config,
          hp: 31,
          attack: 31,
          defense: 31,
          spatk: 31,
          spdef: 31,
          speed: 31,
        });
        break;
      case 'trick_room':
        onChange({
          ...config,
          hp: 31,
          attack: 31,
          defense: 31,
          spatk: 31,
          spdef: 31,
          speed: 0, // 0 Spe
          nature: 'Brave',
        });
        break;
    }
  };

  const statItems: { key: keyof Omit<IVTargetConfig, 'nature' | 'useEverstone' | 'hasHiddenAbility'>; label: string; icon: React.ReactNode; color: string }[] = [
    { key: 'hp', label: 'PS (HP)', icon: <Heart className="w-3.5 h-3.5" />, color: 'text-rose-400' },
    { key: 'attack', label: 'Ataque', icon: <Sword className="w-3.5 h-3.5" />, color: 'text-amber-400' },
    { key: 'defense', label: 'Defensa', icon: <Shield className="w-3.5 h-3.5" />, color: 'text-blue-400' },
    { key: 'spatk', label: 'At. Esp.', icon: <Wand2 className="w-3.5 h-3.5" />, color: 'text-purple-400' },
    { key: 'spdef', label: 'Def. Esp.', icon: <Shield className="w-3.5 h-3.5" />, color: 'text-teal-400' },
    { key: 'speed', label: 'Velocidad', icon: <Gauge className="w-3.5 h-3.5" />, color: 'text-cyan-400' },
  ];

  const handleStatToggle = (statKey: keyof Omit<IVTargetConfig, 'nature' | 'useEverstone' | 'hasHiddenAbility'>) => {
    const current = config[statKey];
    let next = 31;
    if (current === 31) next = -1; // toggle to X
    else if (current === -1) next = 0; // toggle to 0
    else next = 31; // toggle back to 31
    onChange({ ...config, [statKey]: next });
  };

  return (
    <div className="flex flex-col gap-4 p-4 rounded-xl bg-[#0f131c] border border-slate-800">
      {/* Header with presets */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800 pb-3">
        <div>
          <span className="text-sm font-semibold text-white flex items-center gap-1.5">
            <Sparkles className="w-4 h-4 text-purple-400" />
            Constructor de Perfil de IVs
          </span>
          <p className="text-xs text-slate-400">
            Presets competitivos o configuración personalizada de herencia
          </p>
        </div>

        {/* Quick Presets */}
        <div className="flex items-center gap-1.5 flex-wrap">
          <span className="text-[11px] text-slate-500 font-mono uppercase mr-1">Presets:</span>
          <button
            type="button"
            onClick={() => applyPreset('5x31_physical')}
            className="px-2.5 py-1 text-xs rounded-md bg-purple-950/40 text-purple-300 border border-purple-800/60 hover:bg-purple-900/50 hover:border-purple-600 transition-colors"
          >
            5x31 Físico (-SpA)
          </button>
          <button
            type="button"
            onClick={() => applyPreset('5x31_special')}
            className="px-2.5 py-1 text-xs rounded-md bg-blue-950/40 text-blue-300 border border-blue-800/60 hover:bg-blue-900/50 hover:border-blue-600 transition-colors"
          >
            5x31 Especial (0 Atk)
          </button>
          <button
            type="button"
            onClick={() => applyPreset('6x31_absolute')}
            className="px-2.5 py-1 text-xs rounded-md bg-emerald-950/40 text-emerald-300 border border-emerald-800/60 hover:bg-emerald-900/50 hover:border-emerald-600 transition-colors"
          >
            6x31 Absoluto
          </button>
          <button
            type="button"
            onClick={() => applyPreset('trick_room')}
            className="px-2.5 py-1 text-xs rounded-md bg-amber-950/40 text-amber-300 border border-amber-800/60 hover:bg-amber-900/50 hover:border-amber-600 transition-colors"
          >
            Trick Room (0 Spe)
          </button>
        </div>
      </div>

      {/* 6 Stats Selector Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2.5">
        {statItems.map(({ key, label, icon, color }) => {
          const val = config[key];
          const is31 = val === 31;
          const is0 = val === 0;

          return (
            <div
              key={key}
              onClick={() => handleStatToggle(key)}
              className={`p-2.5 rounded-lg border flex flex-col items-center justify-between cursor-pointer transition-all select-none ${
                is31
                  ? 'bg-emerald-950/20 border-emerald-500/50 shadow-[0_0_12px_rgba(16,185,129,0.15)]'
                  : is0
                  ? 'bg-amber-950/20 border-amber-500/50 shadow-[0_0_12px_rgba(245,158,11,0.15)]'
                  : 'bg-slate-900/60 border-slate-800 opacity-70 hover:opacity-100'
              }`}
            >
              <div className="flex items-center gap-1.5 text-xs font-medium text-slate-300">
                <span className={color}>{icon}</span>
                <span>{label}</span>
              </div>

              <div className="my-1.5 flex items-center justify-center">
                <span
                  className={`text-xl font-bold font-mono ${
                    is31
                      ? 'text-emerald-400'
                      : is0
                      ? 'text-amber-400'
                      : 'text-slate-500'
                  }`}
                >
                  {is31 ? '31' : is0 ? '0' : 'X'}
                </span>
              </div>

              <span className="text-[10px] text-slate-400 font-mono">
                {is31 ? 'Máximo' : is0 ? 'Mínimo (0)' : 'Irrelevante'}
              </span>
            </div>
          );
        })}
      </div>

      {/* Nature & Everstone & Hidden Ability Row */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pt-2 border-t border-slate-800/80">
        {/* Nature & Everstone */}
        <div className="p-3 rounded-lg bg-slate-900/50 border border-slate-800 flex flex-col gap-2">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-white flex items-center gap-1.5">
              <Zap className="w-3.5 h-3.5 text-purple-400" />
              Naturaleza y Piedra Eterna
            </span>
            <label className="flex items-center gap-1.5 text-xs text-slate-300 cursor-pointer">
              <input
                type="checkbox"
                checked={config.useEverstone}
                onChange={(e) => onChange({ ...config, useEverstone: e.target.checked })}
                className="rounded border-slate-700 text-purple-600 focus:ring-purple-500 bg-slate-800"
              />
              <span>Fijar Naturaleza (+10,000 Pk$)</span>
            </label>
          </div>

          <div className="flex items-center gap-2">
            <select
              value={config.nature}
              onChange={(e) => onChange({ ...config, nature: e.target.value })}
              className="w-full text-xs px-3 py-2 rounded-md bg-[#0a0e17] border border-slate-700 text-white focus:border-purple-500 focus:outline-none"
            >
              {COMMON_NATURES.map((nat) => (
                <option key={nat.name} value={nat.name}>
                  {nat.es} ({nat.name}) — +{nat.plus}, -{nat.minus}
                </option>
              ))}
            </select>
          </div>
          {config.useEverstone && (
            <p className="text-[11px] text-purple-400/90 font-mono">
              ★ Consume 1x Piedra Eterna (10,000 Pk$ en tienda Diosesmon)
            </p>
          )}
        </div>

        {/* Hidden Ability */}
        <div className="p-3 rounded-lg bg-slate-900/50 border border-slate-800 flex flex-col gap-2">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-white flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5 text-amber-400" />
              Habilidad Oculta (HA)
            </span>
            <label className="flex items-center gap-1.5 text-xs text-slate-300 cursor-pointer">
              <input
                type="checkbox"
                checked={config.hasHiddenAbility}
                onChange={(e) => onChange({ ...config, hasHiddenAbility: e.target.checked })}
                className="rounded border-slate-700 text-amber-500 focus:ring-amber-500 bg-slate-800"
              />
              <span>Requerir Habilidad Oculta</span>
            </label>
          </div>

          <p className="text-xs text-slate-400 leading-relaxed">
            {config.hasHiddenAbility ? (
              <span className="text-amber-300">
                ⚠ La hembra base inicial (o macho si cruzas con Ditto) debe poseer la Habilidad Oculta (tasa de herencia del 80%).
              </span>
            ) : (
              'La cría heredará cualquiera de las habilidades estándar de la especie materna sin restricción de HA.'
            )}
          </p>
        </div>
      </div>
    </div>
  );
};

export default IVProfileBuilder;
