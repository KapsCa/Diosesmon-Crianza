import React, { useState } from 'react';
import { ShieldCheck, Flame, Coins, ChevronDown, ChevronUp, CheckCircle2 } from 'lucide-react';

export const ServerRulesBanner: React.FC = () => {
  const [expanded, setExpanded] = useState(false);

  return (
    <div className="w-full bg-[#0f131c] border border-purple-500/30 rounded-xl overflow-hidden shadow-lg">
      {/* Top Banner Row */}
      <div className="px-4 py-3 bg-gradient-to-r from-purple-950/40 via-slate-900/60 to-purple-950/40 flex flex-wrap items-center justify-between gap-3 border-b border-purple-500/20">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-lg bg-purple-500/20 border border-purple-500/40 flex items-center justify-center text-purple-400">
            <ShieldCheck className="w-4 h-4" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-sm font-semibold text-white tracking-wide">
                Motor de Reglas Diosesmon v1.0
              </span>
              <span className="inline-flex items-center gap-1 text-[11px] px-2 py-0.5 rounded-full bg-emerald-500/15 text-emerald-400 border border-emerald-500/30 font-medium">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                100% Determinista
              </span>
            </div>
            <p className="text-xs text-slate-400">
              Cálculo con consumibles 1x Burn, cuota de 20,000 Pk$ y 0% RNG en IVs
            </p>
          </div>
        </div>

        {/* Quick telemetry badges */}
        <div className="flex items-center gap-2 flex-wrap">
          <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-amber-500/10 border border-amber-500/30 text-amber-300 text-xs font-mono">
            <Coins className="w-3.5 h-3.5 text-amber-400" />
            <span>Guardería: <strong>20,000 Pk$</strong></span>
          </div>

          <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs font-mono">
            <Flame className="w-3.5 h-3.5 text-rose-400" />
            <span>Power Items: <strong>15,000 Pk$ (1x Burn)</strong></span>
          </div>

          <button
            type="button"
            onClick={() => setExpanded(!expanded)}
            className="flex items-center gap-1 text-xs text-purple-300 hover:text-purple-200 px-2 py-1 rounded bg-purple-900/30 border border-purple-500/20 transition-colors"
          >
            <span>{expanded ? 'Ocultar Reglas' : 'Ver Reglas'}</span>
            {expanded ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
          </button>
        </div>
      </div>

      {/* Expandable details */}
      {expanded && (
        <div className="p-4 grid grid-cols-1 md:grid-cols-3 gap-3 bg-[#0a0e17]/80 text-xs text-slate-300 border-t border-slate-800">
          <div className="p-3 rounded-lg bg-slate-900/70 border border-slate-800 flex flex-col gap-1.5">
            <div className="flex items-center gap-2 text-rose-400 font-semibold">
              <Flame className="w-4 h-4" />
              <span>Consumo 1x Burn de Ítems</span>
            </div>
            <p className="text-slate-400 leading-relaxed">
              En Diosesmon, los Power Items (15,000 Pk$) y la Piedra Eterna (10,000 Pk$) <strong>se destruyen tras cada eclosión</strong>. Nuestra calculadora audita cada ítem unitario para evitar déficits en tu inventario.
            </p>
          </div>

          <div className="p-3 rounded-lg bg-slate-900/70 border border-slate-800 flex flex-col gap-1.5">
            <div className="flex items-center gap-2 text-amber-400 font-semibold">
              <Coins className="w-4 h-4" />
              <span>Tarifa de Guardería por Cruza</span>
            </div>
            <p className="text-slate-400 leading-relaxed">
              Cada ciclo en la guardería de Diosesmon tiene una tasa fija de <strong>20,000 Pk$</strong>. La optimización algorítmica reduce la profundidad de generaciones para minimizar este costo base acumulado.
            </p>
          </div>

          <div className="p-3 rounded-lg bg-slate-900/70 border border-slate-800 flex flex-col gap-1.5">
            <div className="flex items-center gap-2 text-emerald-400 font-semibold">
              <CheckCircle2 className="w-4 h-4" />
              <span>Determinismo & Paridad ♂/♀</span>
            </div>
            <p className="text-slate-400 leading-relaxed">
              Se garantiza que la especie resultante sea siempre la de la <strong>madre</strong> (o base con Ditto) y nunca se emparejen dos progenitores del mismo género. 0% RNG en herencia de IVs seleccionados.
            </p>
          </div>
        </div>
      )}
    </div>
  );
};

export default ServerRulesBanner;
