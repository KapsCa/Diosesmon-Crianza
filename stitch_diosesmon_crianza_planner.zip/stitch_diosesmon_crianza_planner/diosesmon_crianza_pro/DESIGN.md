---
name: Diosesmon Crianza Pro
colors:
  surface: '#0f131c'
  surface-dim: '#0f131c'
  surface-bright: '#353943'
  surface-container-lowest: '#0a0e17'
  surface-container-low: '#181b25'
  surface-container: '#1c1f29'
  surface-container-high: '#262a34'
  surface-container-highest: '#31353f'
  on-surface: '#dfe2ef'
  on-surface-variant: '#cfc2d6'
  inverse-surface: '#dfe2ef'
  inverse-on-surface: '#2c303a'
  outline: '#988d9f'
  outline-variant: '#4d4354'
  surface-tint: '#ddb7ff'
  primary: '#ddb7ff'
  on-primary: '#490080'
  primary-container: '#b76dff'
  on-primary-container: '#400071'
  inverse-primary: '#842bd2'
  secondary: '#7bd0ff'
  on-secondary: '#00354a'
  secondary-container: '#00a6e0'
  on-secondary-container: '#00374d'
  tertiary: '#f9bd22'
  on-tertiary: '#402d00'
  tertiary-container: '#b88900'
  on-tertiary-container: '#372700'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#f0dbff'
  primary-fixed-dim: '#ddb7ff'
  on-primary-fixed: '#2c0051'
  on-primary-fixed-variant: '#6900b3'
  secondary-fixed: '#c4e7ff'
  secondary-fixed-dim: '#7bd0ff'
  on-secondary-fixed: '#001e2c'
  on-secondary-fixed-variant: '#004c69'
  tertiary-fixed: '#ffdf9f'
  tertiary-fixed-dim: '#f9bd22'
  on-tertiary-fixed: '#261a00'
  on-tertiary-fixed-variant: '#5c4300'
  background: '#0f131c'
  on-background: '#dfe2ef'
  surface-variant: '#31353f'
typography:
  headline-xl:
    fontFamily: Sora
    fontSize: 40px
    fontWeight: '700'
    lineHeight: 48px
  headline-xl-mobile:
    fontFamily: Sora
    fontSize: 30px
    fontWeight: '700'
    lineHeight: 38px
  headline-lg:
    fontFamily: Sora
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 36px
  headline-lg-mobile:
    fontFamily: Sora
    fontSize: 22px
    fontWeight: '600'
    lineHeight: 30px
  headline-md:
    fontFamily: Sora
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  headline-sm:
    fontFamily: Sora
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 24px
  body-lg:
    fontFamily: Hanken Grotesk
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Hanken Grotesk
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  body-sm:
    fontFamily: Hanken Grotesk
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 18px
  label-lg:
    fontFamily: JetBrains Mono
    fontSize: 13px
    fontWeight: '600'
    lineHeight: 18px
  label-md:
    fontFamily: JetBrains Mono
    fontSize: 11px
    fontWeight: '500'
    lineHeight: 16px
  label-sm:
    fontFamily: JetBrains Mono
    fontSize: 10px
    fontWeight: '500'
    lineHeight: 14px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter-xs: 0.25rem
  gutter-sm: 0.5rem
  gutter-md: 1rem
  gutter-lg: 1.5rem
  gutter-xl: 2rem
  margin-mobile: 1rem
  margin-tablet: 1.5rem
  margin-desktop: 2.5rem
  max-width-content: 88rem
---

## Brand & Style

This design system establishes a focused, high-precision competitive breeding and telemetry dashboard for Diosesmon Crianza. The aesthetic pairs the gravitas of deep charcoal-slate substrates with ethereal celestial tones: luminescent violets, serene indigos, and subtle gilded accents drawn directly from the iconic crowned emblem. 

The visual movement blends Modern Enterprise Dashboard architecture with soft, ambient Glassmorphism. Rather than abrasive gaming neon, the system leverages muted saturation, refined micro-borders, and deep atmospheric glows. The emotional profile conveys expertise, mastery, analytical clarity, and mystical refinement, empowering trainers and breeders with seamless data visualization, genetic lineage trees, and IV/EV optimization matrices.

## Colors

The color palette is built exclusively around an ultra-deep, high-contrast dark environment designed for extended analytical sessions:

- **Neutral Foundations**: Base canvas defaults to Charcoal Void (`#090d16`), elevating across tiered surfaces to Slate Deep (`#0d111c`) and Midnight Slate (`#131826`). Subtle container borders use a low-opacity slate stroke (`rgba(99, 102, 241, 0.12)`).
- **Primary Violet Spectrum**: Led by Mystic Purple (`#a855f7`), accented with Bright Violet (`#c084fc`) for interactive hovers and Soft Violet (`#8b5cf6`) for active indicators and secondary highlights.
- **Secondary Atmospheric Indigos & Cyans**: Serene Cyan (`#38bdf8`) paired with Deep Indigo (`#6366f1`) and Midnight Indigo Abyss (`#1e1b4b`) create telemetry depth, optimal for stat delta indicators, gender distinctions, and secondary data bars.
- **Tertiary Divine Gold**: Inspired by the Diosesmon crown, Gilded Amber (`#fbbf24`) is reserved strictly for high-tier statuses (100% IVs, Hidden Abilities, Legendary lineages, and primary CTA accents).
- **Functional Semantics**: Success (`#34d399`), Warning (`#fbbf24`), Danger/Deficit (`#f43f5e`), and Informational Calm (`#38bdf8`).

## Typography

Typography balances scientific structure with modern digital aesthetics:

- **Headlines (Sora)**: Imparts a geometric, high-tech identity with broad horizontal proportion, providing unmistakable authority to breeding tier titles, species designations, and metric milestones.
- **Body & Interface Text (Hanken Grotesk)**: Provides maximum legibility and frictionless scanning within dense data grids, pedigree tables, and tooltips.
- **Data & Metric Labels (JetBrains Mono)**: Utilized for all discrete technical telemetry—individual values (IVs), effort points (EVs), nature modifiers, breeding seed hash strings, and server command scripts.

## Layout & Spacing

The layout is built on a responsive 12-column modular grid structured for information density without visual claustrophobia:

- **Desktop (1024px and above)**: 12 columns with 24px gutters, fixed lateral navigation rails (compacted or expanded), and safe horizontal margins of 40px. Content is capped at a maximum width of 1408px to maintain focal discipline.
- **Tablet (768px – 1023px)**: 8 columns with 16px gutters and 24px margin padding. Pedigree flow diagrams and side-by-side comparative matrices collapse into multi-level vertical accordions.
- **Mobile (< 768px)**: 4 columns with 12px gutters and 16px margins. Metric columns prioritize stacked single-stat readouts with horizontal swipeable cards for comparative breeding partners.
- **Rhythm Principle**: Internal element spacing strictly abides by an 8-point harmonic unit (`4px`, `8px`, `16px`, `24px`, `32px`, `48px`).

## Elevation & Depth

Visual depth is achieved through layered tonal substrates, subtle radial edge bleeds, and soft-diffused ambient glows rather than aggressive drop shadows:

- **Base Layer (L0)**: `#090d16` canvas background with very subtle ambient radial gradients (`radial-gradient(ellipse at 50% 0%, rgba(99, 102, 241, 0.08), transparent 70%)`).
- **Surface Tier 1 (L1 - Panels & Tables)**: `#0d111c` with a 1px boundary stroke of `rgba(255, 255, 255, 0.06)`.
- **Surface Tier 2 (L2 - Interactive Cards & Modals)**: `#131826` with a delicate outer shadow: `0 8px 32px -4px rgba(0, 0, 0, 0.6), 0 0 1px 1px rgba(168, 85, 247, 0.15)`.
- **Focus & Special Accents (L3 - Divine/Gilded Statuses)**: Soft gold atmospheric backlight: `0 0 24px -2px rgba(251, 191, 36, 0.12), inset 0 1px 0 0 rgba(251, 191, 36, 0.25)`.
- **Glassmorphic Overlays**: Modals and floating action toolbars employ backdrop blur (`16px`) over `rgba(13, 17, 28, 0.75)` with a hairline stroke of `rgba(168, 85, 247, 0.2)`.

## Shapes

The geometric framework balances contemporary software polish with functional modularity:

- **Base Curvature**: `roundedness: 2` (Standard elements carry 8px radius; cards, modals, and container shells carry 16px; secondary child badges and chips use 6px or full circular pill radii).
- **Proportions**: Stat indicators and slot representations maintain symmetrical 1:1 ratios for miniature species sprites and item hold-slots, framed in micro-chamfered or smooth rounded-lg containment.

## Components

### Buttons & Actions
- **Primary (Gilded / Mythic)**: Gilded Amber gradient fill (`linear-gradient(135deg, #fbbf24 0%, #d97706 100%)`) with dark slate typography (`#090d16`, font-weight: 700), reserved for confirmation, breeding execution, and high-tier transactions.
- **Secondary (Arcane Violet)**: Semi-translucent violet base (`rgba(168, 85, 247, 0.12)`) with a crisp violet border (`rgba(168, 85, 247, 0.4)`), hover transition to `rgba(168, 85, 247, 0.25)` with text in `#c084fc`.
- **Ghost / Utility**: Monospaced font label, borderless slate base with cyan hover state (`#38bdf8`).

### Cards & Telemetry Panels
- **Breeding Pair Slot**: L2 surface (`#131826`) bordered in faint indigo, featuring dual gender badge chips (Male: `#38bdf8`, Female: `#f472b6`), compatibility percentage gauges, and real-time pass-down probability metrics.
- **Egg / Incubation Tracker**: Circular SVG progress ring in `#a855f7` with ambient glow pulses upon cycle completion.

### Stat Hexagons & IV Progress Bars
- **Bars**: 6px height track in `#1e1b4b` with active fills in `#38bdf8` (EVs) and `#a855f7` (IVs). Perfect 31 IV stats trigger a specialized Gilded Amber shimmer (`#fbbf24`).
- **Labels**: Rendered strictly in `JetBrains Mono` with contrasting labels (`HP`, `ATK`, `DEF`, `SPA`, `SPD`, `SPE`).

### Chips & Badges
- **Gene Heritage Badges**: Micro pills (`0.75rem` padding horizontal, `0.2rem` vertical) utilizing muted backdrop opacities (`rgba(x, y, z, 0.15)`) with high-contrast text to signal Hidden Abilities, Nature modifiers (+Stat in cyan, -Stat in muted rose), and Ball types.

### Inputs & Selectors
- **Search & Gene Filter**: Deep slate field (`#090d16`) with inner shadow, hairline border (`rgba(255, 255, 255, 0.08)`), focusing to `#a855f7` with an ambient `0 0 0 3px rgba(168, 85, 247, 0.2)` ring.
- **Checkboxes & Radios**: 18px squircle with custom subtle checkmark in Gilded Gold or Violet, maintaining accessible tactile hit targets of 40px minimum.