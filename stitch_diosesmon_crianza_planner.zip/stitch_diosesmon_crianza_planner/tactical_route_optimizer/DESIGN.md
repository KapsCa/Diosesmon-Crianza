---
name: Tactical Route Optimizer
colors:
  surface: '#0f131d'
  surface-dim: '#0f131d'
  surface-bright: '#353944'
  surface-container-lowest: '#0a0e18'
  surface-container-low: '#171b26'
  surface-container: '#1c1f2a'
  surface-container-high: '#262a35'
  surface-container-highest: '#313540'
  on-surface: '#dfe2f1'
  on-surface-variant: '#bec8d2'
  inverse-surface: '#dfe2f1'
  inverse-on-surface: '#2c303b'
  outline: '#88929b'
  outline-variant: '#3e4850'
  surface-tint: '#89ceff'
  primary: '#89ceff'
  on-primary: '#00344d'
  primary-container: '#0ea5e9'
  on-primary-container: '#003751'
  inverse-primary: '#006591'
  secondary: '#ffb95f'
  on-secondary: '#472a00'
  secondary-container: '#ee9800'
  on-secondary-container: '#5b3800'
  tertiary: '#4edea3'
  on-tertiary: '#003824'
  tertiary-container: '#00b17b'
  on-tertiary-container: '#003b26'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#c9e6ff'
  primary-fixed-dim: '#89ceff'
  on-primary-fixed: '#001e2f'
  on-primary-fixed-variant: '#004c6e'
  secondary-fixed: '#ffddb8'
  secondary-fixed-dim: '#ffb95f'
  on-secondary-fixed: '#2a1700'
  on-secondary-fixed-variant: '#653e00'
  tertiary-fixed: '#6ffbbe'
  tertiary-fixed-dim: '#4edea3'
  on-tertiary-fixed: '#002113'
  on-tertiary-fixed-variant: '#005236'
  background: '#0f131d'
  on-background: '#dfe2f1'
  surface-variant: '#313540'
typography:
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 22px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
  title-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 15px
    fontWeight: '600'
    lineHeight: 20px
  title-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 13px
    fontWeight: '600'
    lineHeight: 18px
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  body-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
  label-mono-lg:
    fontFamily: JetBrains Mono
    fontSize: 13px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.02em
  label-mono-md:
    fontFamily: JetBrains Mono
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 14px
    letterSpacing: 0.04em
  label-mono-sm:
    fontFamily: JetBrains Mono
    fontSize: 10px
    fontWeight: '600'
    lineHeight: 12px
    letterSpacing: 0.06em
  metric-stat:
    fontFamily: JetBrains Mono
    fontSize: 20px
    fontWeight: '700'
    lineHeight: 24px
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  node-gap-x: 3rem
  node-gap-y: 1.5rem
  pad-card-sm: 0.625rem
  pad-card-md: 1rem
  gutter-canvas: 1.5rem
---

## Brand & Style

This design system delivers a high-precision, competitive breeding workstation aesthetic tailored for complex generation routing, IV gene tracking, and item economy management. The design rejects juvenile gamification in favor of a sleek tactical interface—evoking telemetry software, financial modeling suites, and competitive esports theorycrafting HUDs.

Key visual attributes:
- **Analytical & Deterministic:** Clean structural boundaries, dense tabular alignment, and zero-distraction layouts that prioritize data throughput and route legibility.
- **Dark-Engine Modernism:** A layered slate-navy canvas layered with crisp laser accents (cyan, amber, emerald) to signal lineage status and algorithmic optimization paths.
- **Mechanical Precision:** Controlled monospaced micro-data alongside crisp geometric typography, engineered for high-density stat comparisons without cognitive fatigue.

## Colors

The palette operates under a high-contrast dark model calibrated for prolonged planning sessions and multi-step lineage parsing.

- **Primary Canvas & Surfaces:**
  - Base Viewport Canvas: `#0B0F19` (Obsidian Slate)
  - Card & Container Surface: `#111827` (Deep Navy Gray)
  - Elevated Node & Popover Surface: `#1E293B` (Layered Slate)
  - Ghost Borders & Structural Dividers: `#334155` (Subdued Gunmetal, opacity 0.5–1.0)
- **Primary Engine Accents:**
  - `#0EA5E9` (Electric Sky) for active nodes, focused paths, and tactical highlights.
  - `#38BDF8` (Luminous Cyan) for interactive hovers and terminal target selections.
- **Economy & Consumables:**
  - `#F59E0B` (Vibrant Amber/Gold) designated strictly for item requirements, Pokédollar costs, and Everstone / Destiny Knot assignments.
- **Biometric & Lineage Semantics:**
  - Male Indicator: `#60A5FA` (Soft Male Azure)
  - Female Indicator: `#F472B6` (Rosy Orchid)
  - Genderless / Transform: `#A855F7` (Amethyst Purple)
- **Validation & Yield States:**
  - Passed / Max IVs (31) & Success Confirmations: `#10B981` (Emerald Green)
  - Bottlenecks, Incompatibilities, & Resource Warnings: `#EF4444` (Crimson Red)
  - Inherited / Static IV Inactive: `#64748B` (Muted Slate)

## Typography

The type system blends contemporary geometric clarity with industrial monospaced telemetry.

- **Primary Interface (`Plus Jakarta Sans`):** Drives headlines, route names, navigational menus, and contextual descriptions. Crisp apertures and proportional balances preserve legibility under dense informational configurations.
- **Tactical Data & IV Telemetry (`JetBrains Mono`):** Applied to all discrete stats (HP, Atk, Def, SpA, SpD, Spe), parentage generation indices (e.g., `GEN-0`, `STEP-2`), financial figures, currency badges, and node connector timestamps. Tabular figures prevent layout shifting during dynamic calculation changes.

## Layout & Spacing

The canvas leverages a dual layout architecture:
1. **Interactive Node Workbench:** An infinite or expansive horizontal fluid tree space structured with `3rem` horizontal generation deltas (`node-gap-x`) and `1.5rem` vertical lineage gaps (`node-gap-y`). Step tiers progress laterally from left to right (`Step 0: Wild/Catch` -> `Step 1: Intermediate Pairings` -> `Final Target`).
2. **Fixed Control & Telemetry Panel:** A persistent side/top docket with a 12-column grid utilizing `1rem` column gutters and `1.5rem` outer viewport margins.

**Responsive Adjustments:**
- **Desktop (1280px+):** Side-by-side display featuring route parameter toggles on the left (320px fixed) and the visual tree graph spanning the remaining fluid container.
- **Tablet (768px - 1279px):** Node canvas shifts to collapsible viewport controls; route comparison metrics collapse into a top floating pinned rail.
- **Mobile (<768px):** Tree nodes reflow into a vertically stacked progressive lineage accordion, replacing the horizontal tree graph with an interactive step-by-step ladder.

## Elevation & Depth

Visual hierarchy uses a refined tactical layering framework based on surface tonal tiering and low-contrast perimeter rings rather than heavy diffused drop shadows:

- **Layer 0 (Base Canvas):** `#0B0F19` with a subtle 24px isometric grid pattern composed of `#1E293B` at 20% opacity.
- **Layer 1 (Card & Sub-nodes):** `#111827` framed with a 1px solid hairline outline of `#334155` (alpha 0.5). Elevation 0.
- **Layer 2 (Selected & Interactive Nodes):** `#1E293B` with a 1px border colored by node state (`#0EA5E9` for active/target, `#F59E0B` for consumable-heavy hubs).
- **Layer 3 (Overlays & Cost Drawers):** `#1E293B` surrounded by an inner glow `inset 0 1px 0 0 rgba(255, 255, 255, 0.05)` and a razor-thin shadow: `0 8px 32px -4px rgba(0, 0, 0, 0.6)`.
- **Connector Vectors:** 2px path strokes rendered in `#334155` for standard branches, transitioning to `#0EA5E9` with a subtle SVG stroke dash animation for the currently traced optimal path.

## Shapes

The design system employs a disciplined, soft-cornered visual grammar (`roundedness: 1`, 0.25rem to 0.5rem base radius). This produces tight, utilitarian contours that maximize screen real estate and echo military/scientific hardware interfaces:

- **Node Cards & Panels:** `0.375rem` (6px) perimeter radius to preserve technical sharpness.
- **Stat & Micro Badges:** `0.25rem` (4px) inner corner radius.
- **Interactive Action Buttons & Route Tabs:** `0.375rem` (6px).
- **Pill Exceptions:** Gender indicator badges and circular species avatars utilize complete rounded radii (`9999px`) to immediately separate entity markers from geometric stat boxes.

## Components

### Breeding Tree Node Cards
- **Structure:** Modular container width fixed at 240px. Header contains species sprite (32x32px circular border), base name, generation tag (`GEN-0`), and a circular gender badge (`♂` in `#60A5FA` or `♀` in `#F472B6`).
- **IV Data Matrix:** A 6-cell horizontal strip rendered in `JetBrains Mono` (`label-mono-sm`): `HP`, `ATK`, `DEF`, `SPA`, `SPD`, `SPE`.
  - Max passed stat (31): Solid `#10B981` background with `#FFFFFF` text.
  - Inactive / Random stat (`X`): Background `#1E293B` with `#64748B` text and 1px `#334155` border.
- **Attached Item Indicator:** Integrated bottom shelf dock holding an icon pill (`#F59E0B` border on dark amber fill) displaying the assigned Power Item (e.g., `B. Bracer`, `Destiny Knot`, `Everstone`).

### Route Comparison Tabs
- Segmented linear controller toggling between `Ruta Económica` (Cost-minimized) and `Ruta Rápida` (Step/Generation-minimized).
- Visual Style: Inset track (`#0B0F19`) housing flush segment buttons. The active segment activates a high-contrast `#1E293B` surface with a 1px `#0EA5E9` border and cyan ambient glow.

### Cost & Metric Badges
- Triple-metric summary cards displaying:
  1. **Pokédollars Total:** Golden coin glyph paired with formatted monospace currency (`₽ 140,000`) in `#F59E0B`.
  2. **Consumable Vigor:** Power item burn counter (e.g., `14x Power Items`, `2x Everstone`).
  3. **Generational Depth:** Total egg cycles and breeding steps required (`label-mono-lg`).

### Branching Lineage Connectors
- Orthogonal SVG vector paths linking parent nodes to child outcomes.
- Default path: Solid 1.5px `#334155`.
- Selected optimal lineage: 2px `#0EA5E9` with directional gradient arrows denoting the flow of inherited stats.
- Merge points display an inherited gene pill (e.g., `Guaranteed 5IV (HP/Def/SpA/SpD/Spe)`).

### Form Controls & Filter Inputs
- **Inputs:** Dark navy (`#0B0F19`) background with recessed top border, crisp focus rings in `#0EA5E9`.
- **Search Dropdowns:** Live-query species picker featuring localized sprites, typing tags, and native egg group flags.