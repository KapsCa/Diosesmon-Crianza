# Product Requirements Document (PRD) — Diosesmon Crianza

**Estado:** Aprobado / En Fase de Implementación Visual  
**Producto:** Diosesmon Crianza (Tactical Breeding Optimizer)  
**Entorno Objetivo:** Web Application (Desktop First, Dark Theme Pro)  
**Versión:** 1.0.0  
**Fecha:** Octubre 2024  

---

## 1. Resumen Ejecutivo (Executive Summary)

**Diosesmon Crianza** es una suite táctica y calculadora algorítmica determinista de crianza Pokémon diseñada específicamente para los jugadores de la comunidad y servidor de Cobblemon **Diosesmon**. 

A diferencia de las calculadoras genéricas o las guías teóricas vanilla, esta herramienta modela y resuelve el proceso de crianza considerando las **reglas de servidor particulares de Diosesmon** (donde los *Power Items* y *Piedras Eternas* son **consumibles de un solo uso por cruza** y el costo de guardería es un factor económico determinante). Su objetivo primordial es brindar predictibilidad del 100%, eliminar el desperdicio de Pokédólares (Pk$) y reducir el esfuerzo cognitivo mediante un **Árbol Visual de Linaje** intuitivo y accionable.

---

## 2. Declaración del Problema & Propuesta de Valor

### 2.1 El Problema
- **Desperdicio de Recursos:** Los jugadores invierten cientos de miles de Pk$ en Power Items y cuotas de guardería que se pierden al cometer errores de alternancia de género o cruzas redundantes.
- **Riesgo de Incompatibilidad y Bloqueos de Género:** Especies con ratios desiguales (87.5% ♂ / 12.5% ♀) o mono-género terminan en callejones sin salida si no se planifican los intermediarios (ej. línea Dratini / Magikarp / Gible).
- **Consumibles no-Vanilla:** En Diosesmon, los objetos recios no son equipamientos permanentes; se queman en cada eclosión. Esto invalida las calculadoras convencionales.

### 2.2 La Solución (Propuesta de Valor)
- **Algoritmo Determinista (0% RNG en IVs):** Rutas matemáticas garantizadas paso a paso para alcanzar 5x31 o 6x31 sin depender del azar.
- **Transparencia Financiera Total:** Desglose del costo exacto en Pk$ (tarifas de guardería + lista de compras de NPC para ítems recios).
- **Visualización de Linaje (Generaciones P1 → F1 → F2 → Target):** Diagrama interactivo donde cada nodo muestra el rol del progenitor, IV fijado por ítem y género requerido.

---

## 3. Personas y Usuarios Clave

| Perfil | Descripción | Necesidad Principal |
| :--- | :--- | :--- |
| **Criador Competitivo Hardcore** | Jugador veterano de torneos y Liga Diosesmon. Busca Pokémon 5x31 y 6x31 con Naturalezas específicas y Habilidades Ocultas. | Minimizar el tiempo de cruzas y verificar la compatibilidad de Ditto multi-IV con optimización de costos. |
| **Jugador Casual / Intermedio** | Jugador en progresión que quiere su primer equipo competitivo sin arruinar su economía de Pk$. | Un camino guiado paso a paso ("Ruta Económica") que le diga exactamente qué capturar, qué ítem comprar y cómo cruzar. |
| **Comerciante / Breeder Profesional** | Jugador enfocado en vender crías perfectas en el mercado del servidor. | Saber el costo de producción unitario exacto para fijar márgenes de ganancia en el server. |

---

## 4. Reglas del Dominio & Restricciones Inviolables (Diosesmon Rules Engine)

1. **Consumo Estricto de Power Items (1x Burn):**
   - Cada cruza consume irrevocablemente el Power Item equipado (Pesa, Brazal, Cinto, Lente, Banda, Franja Recia).
   - Costo unitario estándar de NPC: **15,000 Pk$**.
2. **Consumo de Piedra Eterna:**
   - La fijación de naturaleza consume la Piedra Eterna tras eclosionar.
   - Costo unitario estándar de NPC: **10,000 Pk$**.
3. **Tarifa de Guardería:**
   - Costo por ciclo de cruza: **20,000 Pk$**.
4. **Reglas de Género y Especie Base:**
   - La especie resultante de la eclosión siempre corresponde a la **madre** (o a la especie base no-Ditto si se usa Ditto).
   - El sistema debe auditar la paridad ♂/♀ en cada generación para asegurar que nunca se requieran dos progenitores del mismo género para una cruza intermedia.
5. **Herencia de IVs:**
   - 1 Power Item por padre asegura 1 stat específico de cada lado (2 stats bloqueados).
   - En generaciones avanzadas, la consolidación escalonada transfiere los stats pre-fijados minimizando la dispersión de los 3 IVs aleatorios restantes.

---

## 5. Arquitectura de Pantallas & Experiencia de Usuario

La plataforma se estructura en torno a una experiencia desktop fluida y de alta densidad de información:

### 5.1 Pantalla 1: Selección de Cría (Core Configuration & Telemetría)
- **Componentes Clave:**
  - **Cabecera Hero Mística:** Emblema oficial Diosesmon ADN Divino y banner de estado de reglas activas del servidor.
  - **Selector y Búsqueda de Especie:** Filtros rápidos por meta (Garchomp, Lucario, Tyranitar, Togekiss, etc.), grupos huevo y ratios de género.
  - **Constructor de Perfil de IVs:** Presets rápidos (`5x31 Físico (-SpA)`, `5x31 Especial (0 Atk)`, `6x31 Absoluto`, `Trick Room (0 Spe)`).
  - **Naturaleza & Habilidad Oculta:** Asignación de Piedra Eterna y verificación de HA materna.
  - **Selector de Estrategia Algorítmica:** Toggle entre *Ruta Económica (Mínimo Costo)* y *Ruta Rápida (Ditto Multi-IV)*.
  - **Panel de Telemetría:** Costo acumulado estimado (Pk$), cruzas requeridas, unidades de Power Items a comprar y margen de error (0%).
  - **Banco Local de Progenitores:** Integración con especímenes guardados en el PC del usuario.

### 5.2 Pantalla 2: Árbol Visual de Crianza (Breeding Tree Visualizer)
- **Componentes Clave:**
  - **Filtro y Control de Zoom:** Visualización de linaje por generaciones (P1 Bases, F1 3x31, F2 4x31, Target Final).
  - **Tarjetas de Progenitores (Nodos):** Género (♂/♀), IVs marcados (esmeralda para 31, gris para X irrelevante) y chip del ítem recio asignado.
  - **Nodos de Conexión de Cruce:** Muestra el costo individual de la cruza (ej. 20,000 Pk$).
  - **Desglose Financiero y Consumo de Recursos:** Tabla detallada auditando cuotas de guardería, ítems recios a comprar al NPC y advertencias de no-reutilización de consumibles.

### 5.3 Pantallas Complementarias (Roadmap)
- **Pantalla 3: Guía Paso a Paso / Checklist de Guardería:**
  - Modo operativo interactivo para marcar cruzas completadas en vivo frente al NPC del servidor.
- **Pantalla 4: Calculadora de Compatibilidad & Reglas del Servidor:**
  - Matriz de grupos huevo cruzados, calculadora de DittoxGénero y catálogo de precios de consumibles.

---

## 6. Sistema de Diseño e Identidad Visual

- **Nombre del Sistema:** `Diosesmon Crianza Pro`
- **Modo:** Dark Pro Gaming / Tactical Blueprint.
- **Colores Primarios:**
  - **Superficie / Fondo:** Carbón oscuro y azul noche profundo (`#0A0E17`, `#0F131C`, `#181B25`).
  - **Púrpura Místico / Marca:** `#A855F7` / `#C084FC` (acento dominante, botones de acción principal, bordes de nodo).
  - **Azul Eléctrico / Red:** `#38BDF8` / `#6366F1` (enlaces de linaje, conectores de cruza, género masculino).
  - **Rosa Neón:** `#F472B6` (género femenino, stats especiales).
  - **Verde Esmeralda Neón:** `#10B981` (IV 31 asegurado / 100% determinista).
  - **Oro / Ámbar:** `#F59E0B` / `#FEF08A` (corona Diosesmon, moneda Pk$, avisos críticos).
- **Tipografía:**
  - Display / Headings: `Sora` (moderna, técnica, geométrica).
  - Cuerpo / Datos: `Plus Jakarta Sans` / `Inter` con soporte tabular para números y estadísticas.
- **Logotipo Oficial:** Escudo místico con gradiente violeta/cian, conteniendo la doble hélice de ADN entrelazada con el relámpago divino y la corona sutil superior.

---

## 7. Requisitos No Funcionales (NFRs)

- **Latencia de Simulación:** El árbol de cálculo debe generarse en `< 50ms` en cliente (representado visualmente en la barra de estado con `< 2ms`).
- **Determinismo y Consistencia:** Para una misma configuración de especie y padres iniciales, el árbol generado debe ser idempotente.
- **Accesibilidad y Legibilidad:** Relación de contraste mínima de 4.5:1 (WCAG AA) en todas las etiquetas de IVs y precios sobre fondo oscuro.
- **Diseño Responsivo:** Optimizado para resoluciones Desktop (1440x900, 1920x1080) con scroll horizontal paneable en el árbol visual.

---

## 8. Criterios de Aceptación (DoD - Definition of Done)

1. El usuario puede seleccionar cualquier especie compatible y obtener un cálculo completo de P1 a Target.
2. El costo total en Pk$ refleja de forma exacta las tarifas de guardería más el 100% de los ítems recios consumidos (sin asumir reutilización).
3. No se produce ningún cruce inválido por incompatibilidad de género o especie base.
4. El árbol de crianza es legible de un solo vistazo, con distinción clara entre progenitores masculinos y femeninos.
5. El diseño se adhiere en su totalidad al tema morado místico oscuro establecido en el sistema de diseño.
